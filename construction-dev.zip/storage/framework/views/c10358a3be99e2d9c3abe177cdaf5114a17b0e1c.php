
<style type="text/css">
select option { padding: 6px;}

</style>
        <form method="post" id="formNewitemsubmit">
         <?php echo e(csrf_field()); ?> 
        	<div class="row">
                    <div class="col-sm-4">
                      <div class="form-group">
                        <label for="newItemCode">Item Code</label>
                        <input type="text" class="form-control" id="newItemCode" name="newItemCode" placeholder="Item Code" required>
                      </div>
                     </div>
                     <div class="col-sm-5">
                        <div class="form-group">
                            <label for="newItemName">Item Name</label>
                            <input type="text" class="form-control" id="newItemName" name="newItemName" placeholder="Item Name" required>
                          </div>
                     </div>
             </div>
             <div class="row border-top">
             	<div class="col-sm-4">
                	<br>
                	<div class="checkbox">
                        <label>
                          <input type="checkbox" name="isPurchase" id="isPurchase" > I purchase this item
                        </label>
                      </div>
                </div>
             	<div class="col-sm-8">
                	<div class="row">
                    	<div class="col-xs-4">
                        	<div class="form-group">
                                <label for="unitPrice">Unit Price</label>
                                <input type="text" class="form-control" id="pUnitPrice" name="pUnitPrice" placeholder="Unit Price" required>
                              </div>
                        </div>
                        <div class="col-xs-4">
                        	<div class="form-group">
                                <label for="pAccountID">Account</label>
                                <select name="pAccountID" id="pAccountID" class="form-control">
                                	<option value="">-Select Account-</option>
                                    <?php foreach(App\TblAccountType::all() as $accType_obj): ?>
                                    
                                    <?php if($accType_obj->grandChildAccounting->count()): ?>
                                    <optgroup label="<?php echo e($accType_obj->account_type_name); ?>">
                                	<?php foreach($accType_obj->grandChildAccounting as $acc_obj): ?>
                                    <option value="<?php echo e($acc_obj->id); ?>"><?php echo e($acc_obj->account_name); ?></option>
                                    <?php endforeach; ?>
                                    <?php endif; ?>
                                    </optgroup>
                                    <?php endforeach; ?>
                                </select>
                              </div>
                        </div>
                        <div class="col-xs-4">
                        	<div class="form-group">
                                <label for="pTax_item_id">Tax Rate</label>
                                <select name="pTax_item_id" id="pTax_item_id" class="form-control">
                                	<option value="">-Select Tax-</option>
                                    <?php foreach(App\TblTaxRate::all() as $tax_obj): ?>
                                    <option value="<?php echo e($tax_obj->id); ?>"><?php echo e($tax_obj->tax_name); ?></option>
                                    <?php endforeach; ?>
                                </select>
                              </div>
                        </div>
                    </div>
                
                </div>
             </div>
             <div class="row border-top">
             	<div class="col-sm-4">
                <br>
                	<div class="checkbox">
                        <label>
                          <input type="checkbox" checked name="isSale" id="isSale"  onclick="return false"> I sale this item
                        </label>
                      </div>
                </div>
             	<div class="col-sm-8">
                	<div class="row">
                    	<div class="col-xs-4">
                        	<div class="form-group">
                                <label for="sUnitPrice">Unit Price</label>
                                <input type="text" class="form-control" id="sUnitPrice" name="sUnitPrice" placeholder="Unit Price" required>
                              </div>
                        </div>
                        <div class="col-xs-4">
                        	<div class="form-group">
                                <label for="sAccountID">Account</label>
                                <select name="sAccountID" id="sAccountID" class="form-control">
                                	<option value="">-Select Account-</option>
                                    <?php foreach(App\TblAccountType::all() as $accType_obj): ?>
                                    
                                    <?php if($accType_obj->grandChildAccounting->count()): ?>
                                    <optgroup label="<?php echo e($accType_obj->account_type_name); ?>">
                                	<?php foreach($accType_obj->grandChildAccounting as $acc_obj): ?>
                                    <option value="<?php echo e($acc_obj->id); ?>"><?php echo e($acc_obj->account_name); ?></option>
                                    <?php endforeach; ?>
                                    <?php endif; ?>
                                    </optgroup>
                                    <?php endforeach; ?>
                                </select>
                              </div>
                        </div>
                        <div class="col-xs-4">
                        	<div class="form-group">
                                <label for="stax_item_id">Tax Rate</label>
                                <select name="stax_item_id" id="stax_item_id" class="form-control">
                                	<option value="">-Select Tax-</option>
                                    <?php foreach(App\TblTaxRate::all() as $tax_obj): ?>
                                    <option value="<?php echo e($tax_obj->id); ?>"><?php echo e($tax_obj->tax_name); ?></option>
                                    <?php endforeach; ?>
                                </select>
                              </div>
                        </div>
                    </div>
                
                </div>
             </div>
              <button type="submit" id="submitNewItem" class="btn btn-info">Submit</button>
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </form>

    <script>
	//Jquery--------------------------------------------------------------
        $(function () {
			//Validate form new item
			var validator = $("form#formNewitemsubmit").validate({
					ignore: [],
					framework: 'bootstrap',
					errorPlacement: function(error, element) {
						// Append error within linked label
						$( element )
						.closest( "form" )
						.find( "label[for='" + element.attr( "id" ) + "']" )
						.append( error );
					},
					errorElement: "span",
					rules: {
						newItemCode: {
							required: true,
							remote:  {
										url: "/item/existItemCode",
										type: "get"
									 }
							
						},
						newItemName:{
							required: true,
							
						},
						sUnitPrice:{
								required: true,
							},
						pUnitPrice:{
							required: function (element) {
									 if($("#isPurchase").is(':checked')){
										// var e = document.getElementById("pUnitPrice");
										 //return e.value=="" ;     
										return true;             
									 }
									 else
									 {
										 return false;
									 }  
								  }  
							}
					},
					messages: {
						newItemCode: {
							required: "(required)",
							remote:" (This code is exist!)"
							
						},
						newItemName: {
							required: "(required)",
							
						},
						sUnitPrice: {
							required: "(required)",
							
						},
						pUnitPrice:{
							required: "(required)",
							}
					}
				});
			//submit new item
			$(document).on('submit', "#formNewitemsubmit",function (e) {
					 	e.preventDefault();
            			var formData = new FormData(this);
						$.ajax({
								type: "POST",
								processData: false,
								contentType: false,
								url: "/sale/addNewItem",
								data: formData,
								success: function (response) {
								   //alert(response);
								   alert('success');
								},
								error: function () {
									alert('SYSTEM ERROR, TRY LATER AGAIN');
								}
							});
				});
			
		
	});//end document ready
	
	//JavaScript--------------------------------------------------------------
       
    </script>


