	<style type="text/css" media="screen">
		.table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
			 vertical-align:middle;
		}
	</style>
	<table class="table table-hover" id="inventTbl">
        <thead>
            <tr>
                <th>#</th>
                <th>Item Code</th>
                <th>Item Category</th>
                <th>Item Name</th>
                <th>Item Model</th>
                <th>Warrenty</th>
                <th>Warrenty Date</th>
                <th>Picture</th>
                <th>Price</th>
                <th>Description</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
          <?php $array_inv=array();?>
			<?php foreach(App\tbl_sale_invs::all() as $objInv): ?>
				<?php $array_inv[$objInv->item_id]=$objInv->staff_id?>
			<?php endforeach; ?>
             <?php $array_users=array();?>
			<?php foreach(App\Tbl_staffs::all() as $objuser): ?>
				<?php $array_users[$objuser->id]=$objuser->staff_name?>
			<?php endforeach; ?>
            
            
          <?php  $i = 1;  ?>
        	<?php foreach(App\Tbl_item::where('is_actived',0)->get() as $item): ?>
            <?php $arrayobj=$item->getItemCateogry();?>
              	<tr>
                  <td><?php echo e($i); ?></td>
              		<td><?php echo e($item->item_code); ?></td>
              		<td><?php echo e($arrayobj[$item->item_category_id]); ?></td>
              		<td><?php echo e($item->item_name); ?></td>
              		<td><?php echo e($item->item_model); ?></td>
              		<td><?php echo e($item->warrenty); ?></td>
              		<td>
                        <?php if($item->warrenty==1): ?>
                            <?php echo e(date('M d, Y', strtotime($item->warrenty_date_from))); ?> <br> 
                            <?php echo e(date('M d, Y', strtotime($item->warrenty_date_to))); ?>

                        <?php else: ?>
                        	No Warrenty
                        <?php endif; ?>
                    </td>
              		<td>
                        <?php if($item->photo): ?>
                            <input type="hidden" value="<?php echo e($item->photo); ?>" id="photo" name="deletePhoto">
                            <div style="background-image:url(uploads/<?php echo e($item->photo); ?>); background-size:cover; background-position:center; height:50px; width:100px;">
                            
                            </div>
                          
                        <?php else: ?>
                        	<div style="background-image:url(imgs/noimg.png); background-size:cover; background-position:top; height:50px; width:80px; margin-left:10px;">
                            
                        <?php endif; ?>
                    </td>
              		<td>$ <?php echo e($item->price); ?></td>
              		<td><?php echo e($item->description); ?></td>
                    <td>
                        <a href="#" class="selectItem" id="editInv_<?php echo e($item->id); ?>">Edit</a> | 
                        <?php if(array_key_exists($item->id,$array_inv)): ?>
                        	<a href="/assign/<?php echo e($array_inv[$item->id]); ?>"><span style="color:#AA5139; font-style:italic;"><?php echo e(strtoupper($array_users[$array_inv[$item->id]])); ?></span></a>
                        <?php else: ?>
                        	<a href="#" class="deleteItem" id="deleteInv_<?php echo e($item->id); ?>">Delete</a>
                        <?php endif; ?>
                    </td>
                </tr>
              <?php $i++ ?>
       		<?php endforeach; ?>
        </tbody>
    </table>