<?php $__env->startSection('content'); ?>
<style type="text/css" media="screen">
	.glyphicon-search{
		right: 23px;
		top: 3px;
	}
	table.dataTable{
		border-bottom: 1px solid #ccc;
	}
	table.dataTable thead .sorting{
		background:none !important;
	}
	table.dataTable thead .sorting_asc{
		background:none !important;
	}
	tr th, tr td{
		text-align: center;
	}	
</style>
	<div class="container">
		<div class="row">
			<div class="panel panel-default summary">
				<div class="panel-body">
					<div class="col-md-12">
						<button class="btn btn-info" id="btnNewRoom">New Room</button>
						<hr/>
						<table class="table table-hover table-bordered" id="RoomTbl">
					        <thead>
					            <tr>
					                <th>#</th>
					                <th>Room Name</th>
					                <th>Floor</th>
					                <th>Action</th>
					            </tr>
					        </thead>
					        <tbody>
					        <?php $i = 1;?>
					        <?php foreach($condoRoom as $rooms): ?>
					        	<tr>
					        		<td><?php echo e($i); ?></td>
					        		<td><?php echo e($rooms->condo_name); ?></td>
					        		<td><?php echo e($rooms->floor_id); ?></td>
					        		<td>
					        			<a href="#" id="e_<?php echo e($rooms->id); ?>" class="selectRoom">Edit</a> | 
					        			<a href="#" id="d_<?php echo e($rooms->id); ?>" class="selectDelete">Delete</a></td>
					        	</tr>
					        	<?php $i++; ?>
					        <?php endforeach; ?>
					        </tbody>
					    </table>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="modal fade" id="modalNewRoom" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  	<div class="modal-dialog" role="document">
	    	<div class="modal-content">
	      		<div class="modal-header">
	        		<button type="button"  class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        		<h4 class="modal-title" id="myModalLabel"><span id="showTitle"></span> Condo Room </h4>
	      		</div>
	      	<div class="modal-body">

			</div>
	   		</div>
	 	</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jquery'); ?>
	<script src ="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
	<script src ="<?php echo e(asset('js/dataTables.bootstrap.js')); ?>"></script>
	<link rel="stylesheet" href="<?php echo e(asset('css/dataTables.bootstrap.css')); ?>">
    <script>
	
        $(function () {
        	$('#RoomTbl').dataTable( {
				"bPaginate": true
			});
			//add search icon
			$( ".dataTables_filter > label" ).append( "<span class='glyphicon glyphicon-search'></span>" );

       		$(document).on('click', "#btnNewRoom",function () {
				var url = "/newRoomModel";
				$('.modal-body').load(url,function(result){
					$('#modalNewRoom').modal({show:true});
				});
			});

			$(document).on('click',".selectRoom",function(){
				var get_Id=$(this).attr('id');
				var id=get_Id.substr(2,get_Id.length);
				var url = "/editRoom/"+id;
				$('.modal-body').load(url,function(result){
					$('#modalNewRoom').modal({show:true});
				});
				$('#showTitle').html("Edit");
			});
			$(document).on('click', ".selectDelete",function () {
				var get_Id=$(this).attr('id');
				var id=get_Id.substr(2,get_Id.length);
				if(confirm("Are you sure want to delete")==true){
					$.ajax({
						type: "get",
						url: "/deleteRoom",
						data: {room_id:id},
						success: function (response) {
						   if(response == 'yes'){
								swal({
									title:"Delete data Success",
									text:"This update ready!",
									type:"success",  
									timer: 2000,   
									showConfirmButton: false
								});
								window.setTimeout(function(){ document.location.reload(true); }, 2000);
							}
						}
					});
				}
			});
		});

	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>