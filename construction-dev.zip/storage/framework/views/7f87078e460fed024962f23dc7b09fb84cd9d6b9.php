<?php $__env->startSection('content'); ?>
<style type="text/css" media="screen">
	.glyphicon-search{
		right: 23px;
		top: 3px;
	}
	table.dataTable{
		border-bottom: 1px solid #ccc;
	}
	table.dataTable thead .sorting{
		background:none !important;
	}
	table.dataTable thead .sorting_asc{
		background:none !important;
	}
	tr th, tr td{
		text-align: center;
	}	
</style>
	<div class="container">
		<div class="row">
			<div class="panel panel-default summary">
				<div class="panel-body">
					<div class="col-md-12">
						<button class="btn btn-info" id="btnAddNew">Add Supplier</button>
						<hr/>
						<table class="table table-hover table-bordered" id="RoomTbl">
					        <thead>
					            <tr>
					                <th>#</th>
					                <th>Company Name</th>
					                <th>Seller</th>
					                <th>Telephone Number</th>
					                <th>Address</th>
					                <th>Action</th>
					            </tr>
					        </thead>
					        <tbody>
					        <?php $i = 1;?>
					        <?php foreach($supplier as $supp): ?>
					        	<tr class="supplierRow<?php echo e($supp->id); ?>">
					        		<td><?php echo e($i); ?></td>
					        		<td><?php echo e($supp->company_name); ?></td>
					        		<td><?php echo e($supp->seller); ?></td>
					        		<td><?php echo e($supp->phone); ?></td>
					        		<td><?php echo e($supp->address); ?></td>
					        		<td>
					        			<a href="#" id="e_<?php echo e($supp->id); ?>" class="selectEdit">Edit</a> | 
					        			<a href="#" id="d_<?php echo e($supp->id); ?>" class="selectDelete">Delete</a></td>
					        	</tr>
					        	<?php $i++; ?>
					        <?php endforeach; ?>
					        </tbody>
					    </table>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="modal fade" id="modalAddform" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  	<div class="modal-dialog" role="document">
	    	<div class="modal-content">
	      		<div class="modal-header">
	        		<button type="button"  class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        		<h4 class="modal-title" id="myModalLabel">
	        			Supplier Profile
	        		</h4>
	      		</div>
	      	<div class="modal-body">

			</div>
	   		</div>
	 	</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jquery'); ?>
	<script src ="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
	<script src ="<?php echo e(asset('js/dataTables.bootstrap.js')); ?>"></script>
	<link rel="stylesheet" href="<?php echo e(asset('css/dataTables.bootstrap.css')); ?>">
    <script>
	
        $(function () {
        	$('#RoomTbl').dataTable( {
				"bPaginate": true
			});
			//add search icon
			$( ".dataTables_filter > label" ).append( "<span class='glyphicon glyphicon-search'></span>" );

       		$(document).on('click', "#btnAddNew",function () {
				var url = "/newSupplierForm";
				$('.modal-body').load(url,function(result){
					$('#modalAddform').modal({show:true});
				});
			});

			$(document).on('click',".selectEdit",function(){
				var get_Id=$(this).attr('id');
				var id=get_Id.substr(2,get_Id.length);
				var url = "/getSupplierid/"+id;
				$('.modal-body').load(url,function(result){
					$('#modalAddform').modal({show:true});
				});
			});
			$(document).on('click', ".selectDelete",function () {
				var get_Id=$(this).attr('id');
				var id=get_Id.substr(2,get_Id.length);
				if(confirm("Are you sure want to delete")==true){
					$.ajax({
						type: "get",
						url: "/deleteSupplier",
						data: {sup_id:id},
						success: function (response) {
							$('.supplierRow'+id).hide(500);
						   /*if(response == 'yes'){
								swal({
									title:"Delete data Success",
									text:"This update ready!",
									type:"success",  
									timer: 2000,   
									showConfirmButton: false
								});
								window.setTimeout(function(){ document.location.reload(true); }, 2000);
							}*/
						}
					});
				}
			});
		});

	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>