<?php $__env->startSection('content'); ?>

<style type="text/css" media="screen">

/*  bhoechie tab */
div.bhoechie-tab-container{
  z-index: 10;
  background-color: #ffffff;
  padding: 0 !important;
  border-radius: 0px;
  -moz-border-radius: 0px;
  border:1px solid #ddd;
  margin-top: 0px;
  margin-left: 0px;
  -webkit-box-shadow: 0 6px 12px rgba(0,0,0,.175);
  box-shadow: 0 6px 12px rgba(0,0,0,.175);
  -moz-box-shadow: 0 6px 12px rgba(0,0,0,.175);
  background-clip: padding-box;
  opacity: 0.97;
  filter: alpha(opacity=97);
}
div.bhoechie-tab-menu{
  padding-right: 0;
  padding-left: 0;
  padding-bottom: 0;
}
div.bhoechie-tab-menu div.list-group{
  margin-bottom: 0;
}
div.bhoechie-tab-menu div.list-group>a{
  margin-bottom: 0;
}
div.bhoechie-tab-menu div.list-group>a .glyphicon,
div.bhoechie-tab-menu div.list-group>a .fa {
  color: #00ABAB;
}
div.bhoechie-tab-menu div.list-group>a:first-child{
  border-top-right-radius: 0;
  -moz-border-top-right-radius: 0;
}
div.bhoechie-tab-menu div.list-group>a:last-child{
  border-bottom-right-radius: 0;
  -moz-border-bottom-right-radius: 0;
}
div.bhoechie-tab-menu div.list-group>a.active,
div.bhoechie-tab-menu div.list-group>a.active .glyphicon,
div.bhoechie-tab-menu div.list-group>a.active .fa{
  background-color: #00ABAB;
  background-image: #00ABAB;
  color: #ffffff;
}
div.bhoechie-tab-menu div.list-group>a.active:after{
  content: '';
  position: absolute;
  left: 100%;
  top: 50%;
  margin-top: -13px;
  border-left: 0;
  border-bottom: 13px solid transparent;
  border-top: 13px solid transparent;
  border-left: 10px solid #00ABAB;
}

div.bhoechie-tab-content{
  background-color: #ffffff;
  /* border: 1px solid #eeeeee; */
  
}

div.bhoechie-tab div.bhoechie-tab-content:not(.active){
  display: none;
}
	.list-group-item.active, .list-group-item.active:focus, .list-group-item.active:hover {
    	border-color: #00ABAB;
	}
	.room_thumbnail{
		height: 150px; border: 1px solid #00ABAB; border-radius: 0px; margin-bottom: 15px; margin-top: 15px; background-color: #00ABAB; padding-top: 25px; cursor: pointer;
	}
	.content_bg{ background-color: #f9f9f9 !important;}
	.active, .content_bg{
		-webkit-transition: all 0.5s ease;
		-moz-transition: all 0.5s ease;
		-o-transition: all 0.5s ease;
		transition: all 0.5s ease;
	}
	.list-group-item { border-bottom: none;}
	
	
	
	
	input[type=number]::-webkit-inner-spin-button {
	  -webkit-appearance: none;

	}
	.glyphicon-remove{
		cursor: pointer;
	}
	.table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
		padding: 4px;
		
		vertical-align: middle;
		
	}
</style>
<div class="container"> 
	<div class="row bhoechie-tab-container">
							<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 bhoechie-tab-menu">
							  <div class="list-group">
							  	<?php foreach(App\Tbl_Condo_Floor::all() as $objFloor): ?>
								<a href="#" class="list-group-item <?php echo e(($objFloor->id==4)?'active':''); ?>">
								  <span class="glyphicon glyphicon-equalizer" style="margin-top: 0px; padding-bottom: 0px;"></span> <?php echo e($objFloor->floor); ?>

								</a>
								<?php endforeach; ?>
								
							  </div>
							</div>
							<div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 bhoechie-tab" style="padding-top: 15px;">
								<!-- flight section -->
								<?php foreach(App\Tbl_Condo_Floor::all() as $obj2Floor): ?>
								<div class="bhoechie-tab-content <?php echo e(($obj2Floor->id==4)?'active':''); ?>" >
									
							  		
								  	<?php if($obj2Floor->getCondo->count()): ?>
									  <?php foreach($obj2Floor->getCondo as $objCondo): ?>
									  <?php $condo_data=App\Tbl_Condo::all();?>
									  	<div class="col-sm-4 cover_thumbnail" >
									  		<div class="col-xs-12 room_thumbnail" onClick="return selected_room(<?php echo e($obj2Floor->id); ?>,<?php echo e($objCondo->id); ?>);" style="text-align: center;">
									  			<h1 class="glyphicon glyphicon-bed" align="center" style="color: #fff; text-align: center !important;"></h1>
									  			<h4 style="color: #fff;" align="center"><?php echo e($objCondo->condo_name); ?></h4>
									  			<span style="position: absolute; bottom: 5px; left: 5px; color: #ddd; ">
									  				Inventory List (<?php  echo ($condo_data[0]->get_stock_eachroom($objCondo->id)) ?>)
									  				
									  			</span>
									  		</div>
									  	</div>
									  	<!--Table show=====================================-->
									  	<div class="col-sm-12 cover_thumbnail_2" id="<?php echo e($obj2Floor->id); ?>_<?php echo e($objCondo->id); ?>" style="display: none;">
									  		<h1 style="color: #00aba9;"><span class="glyphicon glyphicon-bed"></span> <?php echo e($objCondo->condo_name); ?>

									  			<span style="float: right">
									  				<button type="button" class="btn btn-info" onClick="return add_itemToRoom(<?php echo e($obj2Floor->id); ?>,<?php echo e($objCondo->id); ?>);" ><span class="glyphicon glyphicon-plus"></span> Add item </button>
									  			</span>
									  		</h1>
									  		<table class="table table-striped table-bordered">
									  			<tr>
									  				<th>#</th>
									  				<th>Item Code</th>
									  				<th>Item Name</th>
									  				<th>Amount</th>
									  				<th>Responder</th>
									  				<th>Date</th>
									  				<th></th>
									  			</tr>
									  			<tbody id="showReturnInserted<?php echo e($obj2Floor->id); ?><?php echo e($objCondo->id); ?>">
													
									  			</tbody>
									  			
									  		</table>
									  	</div>
									  	<!--End================================================-->
									  <?php endforeach; ?>
									<?php endif; ?>
									
									
								</div>
								<?php endforeach; ?>
								
							</div>
	</div>
		
</div>

<!-- Modal -->
<div class="modal fade" id="modalAaddItemToRoom" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Select Item to the room</h4>
      </div>
      <div class="modal-body">
       
      </div>
      
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jquery'); ?>

	<script src ="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
	<script src ="<?php echo e(asset('js/dataTables.bootstrap.js')); ?>"></script>
	<link rel="stylesheet" href="<?php echo e(asset('css/dataTables.bootstrap.css')); ?>">
    

    <script>
        $(function () {

			//function submit formAddItemToRoom
			$(document).on('submit', "#formAddItemToRoom",function (e) {
					 	e.preventDefault();
            			var formData = new FormData(this);	
						var floor_id=$("#floor_id").val();
						var room_id=$("#room_id").val();
						$.ajax({
								type: "POST",
								processData: false,
								contentType: false,
								url: "/addItemToRoom",
								data: formData,
								success: function (response) {
									//alert(response);
									if(response!='no'){
										$('#showReturnInserted'+floor_id+room_id).html(response);
										$('#modalAaddItemToRoom').modal('hide');
									}else{
										alert("Error!!!");
									}

								},
								error: function () {
									alert('SYSTEM ERROR, TRY LATER AGAIN');
								}
							});
				});
			//date
			$(".show_current_date").datetimepicker({
               value:new Date(),
                timepicker:false,
                format:'d-M-Y'
            });
			
			
			   $("div.bhoechie-tab-menu>div.list-group>a").click(function(e) {
					e.preventDefault();
				   $('.cover_thumbnail').show(200);
				   $('.cover_thumbnail_2').hide(200);
				   $('.bhoechie-tab-container').removeClass('content_bg');
					$(this).siblings('a.active').removeClass("active");
					$(this).addClass("active");
					var index = $(this).index();
					$("div.bhoechie-tab>div.bhoechie-tab-content").removeClass("active");
					$("div.bhoechie-tab>div.bhoechie-tab-content").eq(index).addClass("active");
				});
			//			
		});//end ready =======================================================================
		
		function selected_room(floorid,roomid){
				//$('#content_select'+floorid).hide();
				 $.get("/showItemToRoom/"+roomid, function(data, status){
					//alert("Data: " + data + "\nStatus: " + status);
					$("#showReturnInserted"+floorid+roomid).html(data);
					$('.cover_thumbnail').hide(500);
					$('#'+floorid+'_'+roomid).show(500);
					$('.bhoechie-tab-container').addClass('content_bg');

				});
			}
		//submit frm item to room 
		
		$(document).on('change', "#item_id",function (e) {
			var item_id=$(this).val();
			
			$.get("/get_stock_eachItem/"+item_id, function(data, status){
				//	alert("Data: " + data + "\nStatus: " + status);
					
					$("#item_qty_old").val(data);
					$("#item_qty_old").css('color','teal');
					$("#item_qty_old").css('font-weight','bold');
				});
					
				
		});
		// check enought stoct item_qty
		$(document).on('blur', "#item_qty",function (e) {
			var val=parseInt($(this).val())||0;
			var stock=parseInt($("#item_qty_old").val())||0;
			
			if(val>0){
				if(val>stock){
					$("#showMsg_stock_error").html('<span style="color:red;">Stock is not enought!</span>');
					$(this).focus();
					$(this).val('');

				}else{
					$("#showMsg_stock_error").html('').fadeOut('slow');
				}
			}else{
				$(this).val('');
			}	
				
		});
		//remove item from room
		function removed_item_fromroom(inv_id,item_stock_id){
			if(confirm('Are sure want to delete this? there is no undo!')==true){
				$.get("/removed_item_fromroom/"+inv_id+"/"+item_stock_id, function(data, status){
					//alert("Data: " + data + "\nStatus: " + status);
					$(".removeInventory"+inv_id+'_'+item_stock_id).hide();
					// var id=get_Id.substr(10,get_Id.length);
				});
			}
		}
		//add item to room
		function add_itemToRoom(floorid,roomid){
			//alert('asdf');
			var url = "/loadformItemToRoom/"+floorid+"/"+roomid;
				$('.modal-body').load(url,function(result){
						$('#modalAaddItemToRoom').modal({show:true, backdrop: 'static', keyboard: false});
					});
			
			/*$.ajax({
						type: "get",
						url: "/addItemToRoom",
						data:{ floor_id:floorid, room_id:roomid},
						success: function(response){
								
							}
						
					});*/
		}

	</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>