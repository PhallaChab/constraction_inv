
<style type="text/css">
input[type=number]::-webkit-inner-spin-button {
  -webkit-appearance: none;

}
	.select2-dropdown { border-radius: 0px;}
	.select2-container { width:100% !important;} 
	.selete-textbox{ 
		height: 28px;
    	border: 1px solid #999;
	}
	.select2-container--default .select2-selection--single {  border-radius: 0px !important; height: 34px !important;}
	.select2-container--default .select2-selection--single .select2-selection__rendered { line-height: 34px;}
</style>
<?php //print_r($array_condo)?>
<form method="post" id="formAddItemToRoom">
	<?php echo e(csrf_field()); ?> 
	<input type="hidden" name="floor_id" id="floor_id" value="<?php echo e($array_condo[0]); ?>">
	<input type="hidden" name="room_id"  id="room_id" value="<?php echo e($array_condo[1]); ?>">
	<div class="form-group">
		<p style="margin: 0px;"><label>Item Category</label></p>
		<select name="item_id" id="item_id" class="form-control select_item_id" required>
			<option value="">-Select Item Category-</option>
			<?php foreach(App\ItemCategory::all() as $objCate): ?>
			<?php if($objCate->getItemList->count()>0): ?>
			<optgroup label="<?php echo e($objCate->category_name); ?>">
				<?php foreach($objCate->getItemList as $objItem): ?>
				<option value="<?php echo e($objItem->id); ?>"><?php echo e($objItem->item_name); ?></option>
				<?php endforeach; ?>
			</optgroup>
			<?php endif; ?>
			<?php endforeach; ?>
		</select>
	</div>
	
	<div class="row">
		<div class="col-xs-4">
			<div class="form-group">
				<label>Current Stock</label>
				<input type="text" name="item_qty_old" id="item_qty_old" class="form-control" readonly>
			</div>
		</div>
		<div class="col-xs-4">
			<div class="form-group">
				<label>Quantity</label>
				<input type="number" name="item_qty" id="item_qty" class="form-control" required placeholder="0">
				<span id="showMsg_stock_error"></span>
			</div>
		</div>
		<div class="col-xs-4">
			<div class="form-group">
				<label>Date</label>
				<input type="text" name="toDate" id="toDate" class="form-control show_current_date" required>
			</div>
		</div>
	</div>
	<hr>
	<div class="form-group">
		<label>Responded By</label>
		<select name="staff_id" id="staff_id" class="form-control" required>
			<option value="">-Select-</option>
			<?php foreach(App\Tbl_staffs::all() as $objStaff): ?>
			<option value="<?php echo e($objStaff->id); ?>"><?php echo e($objStaff->staff_name); ?></option>
			<?php endforeach; ?>
		</select>
	</div>

        <button type="reset" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="submit" name="submit_" class="btn btn-primary submit_">Add Item</button>
   
	
</form>

<script src ="<?php echo e(asset('js/select2.min.js')); ?>"></script>
<link rel="stylesheet" href="<?php echo e(asset('css/select2.css')); ?>">
<script>
	$(function () {
		$(".select_item_id").select2({
		  placeholder: "Select a Item",
		  allowClear: true
		});

		//date
			$(".show_current_date").datetimepicker({
               //value:new Date(),
                timepicker:false,
                format:'d-M-Y'
            });
		//on change category
		$(document).on('change', "#item_categoryx",function () {
			var cateID=$(this).val();
			
			$('#show_itemByCategory').html('');
			$.ajax({
						type: "get",
						url: "/onChangeCategory",
						data:{ cate_id:cateID },
						success: function(response){
							//alert(response);
							$("#item_category").css('color','teal');
							$("#item_category").css('font-weight','bold');
							$('#show_itemByCategory').html(response);
								/*var toAppend = '';
							toAppend +='<select name="item_id" id="item_id" class="form-control" required>';
							  
									$.each(response, function(k,v) {
										   toAppend += '<option value="'+response[k].id+'">'+response[k].item_code+' - '+response[k].item_name+'</option>';
									});
								
							toAppend +='</select>';
								$('#show_itemByCategory').append(toAppend);
								//alert(toAppend);*/
							}
						
					});
		
			// add item  to room
			$("#formAddItemToRoom").ajaxForm({url: '/addItemToRoom"', type: 'post'})
			/*$(document).on('submit', "#formAddItemToRoom",function (e) {
					 	e.preventDefault();
            			var formData = new FormData(this);				
						$.ajax({
								type: "POST",
								processData: false,
								contentType: false,
								url: "/addItemToRoom",
								data: formData,
								success: function (response) {
									//alert(response);
								   $('#modalAaddItemToRoom').modal('hide');
                                   

								},
								error: function () {
									alert('SYSTEM ERROR, TRY LATER AGAIN');
								}
							});
				});*/
			
		});
	});
</script>