<?php 
	$array_gender=array("1"=>"Male","2"=>"Female");
?>
<style type="text/css">
select option { padding: 6px;}
.alert { margin:0px; padding:15px 15px 0px;}
.dateWarrenty{ display:none;}
.optional{ color:#ccc; font-weight:normal;}
#newStaff{ padding-left: 0px !important; }
</style>

	<div class="panel panel-default" style="border:none; padding:0px 0px;">
		<div class="panel-body" style="padding-top:0px; padding-bottom:0px;" >
       
			<form method="post" id="formNewitemsubmit">
				<?php echo e(csrf_field()); ?>

				<input type="hidden" name="itemID" id="itemID" value="<?php echo e(isset($getItemEdit[0])?$getItemEdit[0]->id:''); ?>">
                <div class="row">
                      	<div class="col-xs-6">
                          	<div class="form-group">
                                <label for="barcode">Category</label>
                                <select name="category" id="category" class="form-control">
                                    <option value=""> -Select- </option>
                                        <?php foreach(App\ItemCategory::all() as $categoryObj): ?>
                                        <option value="<?php echo e($categoryObj->id); ?>" 
                                        <?php if(isset($getItemEdit[0])): ?>
                                            <?php if($getItemEdit[0]->item_category_id==$categoryObj->id): ?>
                                                selected
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        >
                                            <?php echo e($categoryObj->category_name); ?>

                                        </option>
                                        <?php endforeach; ?>
                                </select>
                            </div>
                      	</div>
                  	  	<div class="col-xs-6">
                            <div class="form-group">
                                <label for="barcode">Barcode</label>
                                <input type="text" class="form-control" style="color:teal; font-weight:bold;" name="barcode" readonly id="barcode" placeholder="Item Barcode" value="<?php echo e(isset($barcode)?'MW'.date('Ym').$barcode:$getItemEdit[0]->item_code); ?>">
                             </div>
                       	</div>
                   	</div>
            		
                    <div class="row">
                      	<div class="col-xs-6">
                          	<div class="form-group">
                            	<label for="itemname">Item Name</label>
                            	<input type="text" class="form-control" name="itemname" id="itemname" placeholder="Item Name" value="<?php echo e(isset($getItemEdit[0])?$getItemEdit[0]->item_name:''); ?>">
                          	</div>
                      	</div>
                      	<div class="col-xs-6">
                      		<div class="form-group">
                                <label for="price">Price <span class="optional">[Optional]</span></label>
                                <input type="text" class="form-control" name="price" id="price" placeholder="Item Price" value="<?php echo e(isset($getItemEdit[0])?$getItemEdit[0]->price:''); ?>">
                            </div>
                      	</div>
                    </div>
                  	<div class="row">
                      	<div class="col-xs-6">
                          	<div class="form-group">
                            	<label for="itemmodel">Model</label>
                            	<input type="text" class="form-control" name="itemmodel" id="itemmodel" placeholder="Item Model" value="<?php echo e(isset($getItemEdit[0])?$getItemEdit[0]->item_model:''); ?>">
                          	</div>
                      	</div>
                  	  	
                   	</div>

                  <?php /*?><div class="row" style="margin-top: 1px;">
                      <div class="col-xs-12 col-sm-4">
                          <div class="checkbox" style="height:35px;">
                            <label>
                              <input type="checkbox" name="warrenty"  id="warrenty" value="{{isset($getItemEdit[0])?$getItemEdit[0]->warrenty:''}}" 
                             	@if(isset($getItemEdit[0])) 
                                	@if($getItemEdit[0]->warrenty==1)
                                    	checked
                              		@endif
                                @endif
                              > Warrenty?
                            </label>
                          </div>
                      </div>
                      	@if(isset($getItemEdit[0])) 
	                    	@if($getItemEdit[0]->warrenty==1)
	                        	<?php $warrenty='yes';?>
	                  		@endif
	                    @endif
                    <div class="col-xs-6 col-sm-4">
                      	<div class="form-group">
                                <input type="text" class="form-control dateWarrenty" name="datefrom" id="datefrom" placeholder="From" value="{{isset($getItemEdit[0])?$getItemEdit[0]->warrenty_date_from:''}}">
                              </div>
                       </div>
                       <div class="col-xs-6 col-sm-4">
                      	<div class="form-group">
                                <input type="text" class="form-control dateWarrenty" name="dateto" id="dateto" placeholder="To" value="{{isset($getItemEdit[0])?$getItemEdit[0]->warrenty_date_to:''}}">
                              </div>
                       </div>
                   </div><?php */?>
                    <div class="row">
                      	<div class="col-xs-6">
                        	<div class="form-group">
                                <label for="image">Photos  <span class="optional">[Optional]</span>
                                    <span class="optional">(allow *.jpg, *.png)</span>
                                </label>
                                <input type="hidden" id="img" name="photo" value="<?php echo e(isset($getItemEdit[0])?$getItemEdit[0]->photo:''); ?>">
                                <input type="file" id="image" name="image">
                            </div>
                       </div>
                       <div class="col-xs-6">
                       		<div class="form-group hidden">
                                <label for="docsNew">Documents   <span class="optional">[Optional]</span>
                                    <span class="optional">(allow *.PDF)</span>
                                </label>
                                <input type="hidden" id="docs" name="docs" value="<?php echo e(isset($getItemEdit[0])?$getItemEdit[0]->document:''); ?>">
                                <input type="file" id="docsNew" name="docsNew">
                            </div>
                       </div>
                   </div>
                  	<button type="submit" class="btn btn-info">Submit</button>
                  	<button type="reset" class="btn btn-default" class="btn btn-default" data-dismiss="modal">Close</button>
        	</form>
  		</div>      
  	</div> 
    <script>
	var warrenty='<?php echo e(isset($warrenty)?$warrenty:""); ?>';
	if(warrenty=='yes'){
		$('.dateWarrenty').show();
	}else{
		$('.dateWarrenty').hide();
	}
	//Jquery--------------------------------------------------------------
        $(function () {

			$('input[name="warrenty"]').on('click', function(){
				if ( $(this).is(':checked') ) {
					$('.dateWarrenty').show();
				} 
				else {
					$('.dateWarrenty').hide();
				}
			});
			
			$(".dateWarrenty").datetimepicker({
                value:new Date(),
                timepicker:false,
                format:'d-M-Y'
            });
            $(".show_current_date").datetimepicker({
                value:new Date(),
                timepicker:false,
                format:'d-M-Y'
            });	
			//Validate form new item
			var validator = $("form#formNewitemsubmit").validate({
					ignore: [],
					framework: 'bootstrap',
					errorPlacement: function(error, element) {
						// Append error within linked label
						$( element )
						.closest( "form" )
						.find( "label[for='" + element.attr( "id" ) + "']" )
						.append( error );
					},
					errorElement: "span",
					rules: {
						barcode: {
							required: true,
						},
						category:{
							required: true,
						},
						itemname:{
							required: true,
						}
					},
					messages: {
						barcode: {
							required: "(required)",
						},
						category: {
							required: "(required)",
						},
						itemname: {
							required: "(required)",
						}
					}
				});
			//submit new item
			$(document).on('submit', "#formNewitemsubmit",function (e) {

					 	e.preventDefault();
            			var formData = new FormData(this);
						$.ajax({
								type: "POST",
								processData: false,
								contentType: false,
								url: "/item/saveNewItem",
								data: formData,
								success: function (response) {
								   $('#modelNewItem').modal('toggle');
                                    window.setTimeout(function(){ document.location.reload(true); }, 100);

								},
								error: function () {
									alert('SYSTEM ERROR, TRY LATER AGAIN');
								}
							});
				});
			
		
	});//end document ready
	
	//JavaScript--------------------------------------------------------------
       
    </script>


