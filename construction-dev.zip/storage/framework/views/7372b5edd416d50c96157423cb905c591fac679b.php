<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
	
    <title>1Residence Inventory</title>
	<link rel="shortcut icon" href="<?php echo e(asset('imgs/favo.gif')); ?>" /> 
    <!-- Fonts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('css/jquery.datetimepicker.css')); ?>">
    <?php /* <link href="<?php echo e(elixir('css/app.css')); ?>" rel="stylesheet"> */ ?>
	
    <!-- Custom -->
    <link rel="stylesheet" href="<?php echo e(asset('css/sweetalert.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/_mystyle.css')); ?>">
    <style>
        body {
          /*  font-family: 'Lato';*/
        }

        .fa-btn {
            margin-right: 6px;
        }
	
    </style>
</head>
<body id="app-layout">

    
	<?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
   
	 <div class="modal fade" id="modelChangePassword" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class="col-md-11 col-xs-11">
                    <div class="alert alert-info" style="margin:0px; padding:15px 15px 0px;">
                        <h4 align="center">Change Profile</h4>
                    </div>
                </div>
                <div class="col-md-1 col-xs-1">
                    <button type="button"  class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                </div>
            </div>
            <div class="modal-body" style="padding-top:0px;">

            </div>
        </div>
    </div>
</div>
    <!-- JavaScripts -->
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>" integrity="sha384-I6F5OKECLVtK/BL+8iSLDEHowSAfUo76ZL9+kGAgTRdiByINKJaqTPH/QVNS1VDb" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
    <script src ="<?php echo e(asset('js/jquery.datetimepicker.full.js')); ?>"></script>
    <script src ="<?php echo e(asset('js/jquery.validate1.js')); ?>"></script>
    <script src ="<?php echo e(asset('js/sweetalert-dev.js')); ?>"></script>
    <script>
      	
    </script>
	<?php echo $__env->yieldContent('jquery'); ?>
   

<script>
   $(function(){
   		$(document).on('click', "#changePass",function () {
			var url = "/changePassword";
			$('.modal-body').load(url,function(result){
				$('#modelChangePassword').modal({show:true});
			});
		});
   });
</script>


</body>
</html>
