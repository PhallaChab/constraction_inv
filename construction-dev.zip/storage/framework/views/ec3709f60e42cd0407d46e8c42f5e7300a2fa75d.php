<?php 
	$array_gender=array("1"=>"Male","2"=>"Female");
?>
<style type="text/css">
select option { padding: 6px;}
.alert { margin:0px; padding:15px 15px 0px;}
.dateWarrenty{ display:none;}
.optional{ color:#ccc; font-weight:normal;}
#newStaff{ padding-left: 0px !important; }
</style>
<!-- Modal -->
<div class="modal fade" id="newStaff" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  	<div class="modal-dialog" role="document">
	    <div class="modal-content">
	      	<div class="modal-header">
	      		<div class="col-md-6">
	        		<h4 class="modal-title" id="exampleModalLabel">Add New Staff</h4>
	        	</div>
	        	<div class="col-md-6">
	        		<button type="button" class="close closed" aria-label="Close">
	          		<span aria-hidden="true">&times;</span>
	        	</button>
	        	</div>
	      	</div>

	      	<div class="modal-body" style="padding-left:30px; padding-right:30px;">
				<form method="post" id="addStaffForm" action="/addStaffForm">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" value="<?php echo e(isset($getSelectEdit[0])?$getSelectEdit[0]->id:''); ?>" name="staff_id" id="staff_id">
                    
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label">Name</label>
                            <div class="col-md-9">
                                <input class="form-control" type="text" id="fullName" name="fullName" placeholder="Full Name" value="<?php echo e(isset($getSelectEdit[0])?$getSelectEdit[0]->staff_name:''); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label">Saff ID</label>
                              <div class="col-md-9">
                                <input class="form-control" type="text" id="code" name="code" placeholder="0000" maxlength="4" value="<?php echo e(isset($getSelectEdit[0])?$getSelectEdit[0]->staff_code:''); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label">Department</label>
                                <div class="col-md-9">
                                    <select name="department" required class="form-control">
                                        <option value="">--Select--</option>
                                        <?php foreach(App\Tbl_department::all() as $dep): ?>
                                        <option value="<?php echo e($dep->id); ?>"
                                            <?php if(isset($getSelectEdit[0])): ?>
                                                <?php if($getSelectEdit[0]->department_id==$dep->id): ?> 
                                                    selected
                                                <?php endif; ?>
                                           <?php endif; ?>
                                           >
                                           <?php echo e($dep->department_name); ?>

                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                        </div>
                        <div class="form-group row">
                            <label for="mobile" class="col-md-3 col-form-label">Phone Number</label>
                            <div class="col-md-9">
                                <input class="form-control" type="text" id="mobile" name="mobile" placeholder="Phone Number" value="<?php echo e(isset($getSelectEdit[0])?$getSelectEdit[0]->phone_number:''); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label">Gender</label>
                                <div class="col-md-9">
                                    <select name="gender" required class="form-control">
                                    <option value="">-Select-</option>
                                    <?php foreach($array_gender as $ks=>$vs){?>
                                        <option value="<?=$ks?>" <?php if(isset($getSelectEdit[0])){ if($getSelectEdit[0]->gender==$ks){ echo 'selected'; }}?> ><?=$vs?></option>
                                    <?php }?>
                                    
                                    </select>
                                </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label">Position</label>
                              <div class="col-md-9">
                                <input class="form-control" type="text" id="position" name="position" placeholder="IT Support" value="<?php echo e(isset($getSelectEdit[0])?$getSelectEdit[0]->position:''); ?>">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-info">Save changes</button>
                        <button type="button" class="btn btn-secondary closed">Close</button>
                    </form>

	        	
	      	</div>
	      	
	    </div>
  	</div>
</div>

<?php 	//print_r($array_staff); exit;?>
	<div class="panel panel-default" style="border:none; padding:0px 0px;">
		<div class="panel-body" style="padding-top:0px; padding-bottom:0px;" >
       
			<form method="post" id="formNewitemsubmit">
				<?php echo e(csrf_field()); ?>

				<input type="hidden" name="itemID" id="itemID" value="<?php echo e(isset($getItemEdit[0])?$getItemEdit[0]->id:''); ?>">
                <div class="row">
                      	<div class="col-xs-6">
                          	<div class="form-group">
                                <label for="barcode">Category</label>
                                <select name="category" id="category" class="form-control">
                                    <option value=""> -Select- </option>
                                        <?php foreach(App\ItemCategory::all() as $categoryObj): ?>
                                        <option value="<?php echo e($categoryObj->id); ?>" 
                                        <?php if(isset($getItemEdit[0])): ?>
                                            <?php if($getItemEdit[0]->item_category_id==$categoryObj->id): ?>
                                                selected
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        >
                                            <?php echo e($categoryObj->category_name); ?>

                                        </option>
                                        <?php endforeach; ?>
                                </select>
                            </div>
                      	</div>
                  	  	<div class="col-xs-6">
                            <div class="form-group">
                                <label for="barcode">Barcode</label>
                                <input type="text" class="form-control" style="color:teal; font-weight:bold;" name="barcode" readonly id="barcode" placeholder="Item Barcode" value="<?php echo e(isset($barcode)?'MW'.date('Ym').$barcode:$getItemEdit[0]->item_code); ?>">
                             </div>
                       	</div>
                   	</div>
            		
                    <div class="row">
                      	<div class="col-xs-6">
                          	<div class="form-group">
                            	<label for="itemname">Item Name</label>
                            	<input type="text" class="form-control" name="itemname" id="itemname" placeholder="Item Name" value="<?php echo e(isset($getItemEdit[0])?$getItemEdit[0]->item_name:''); ?>">
                          	</div>
                      	</div>
                      	<div class="col-xs-6">
                      		<div class="form-group">
                                <label for="price">Price <span class="optional">[Optional]</span></label>
                                <input type="text" class="form-control" name="price" id="price" placeholder="Item Price" value="<?php echo e(isset($getItemEdit[0])?$getItemEdit[0]->price:''); ?>">
                            </div>
                      	</div>
                    </div>
                  	<div class="row">
                      	<div class="col-xs-6">
                          	<div class="form-group">
                            	<label for="itemmodel">Model</label>
                            	<input type="text" class="form-control" name="itemmodel" id="itemmodel" placeholder="Item Model" value="<?php echo e(isset($getItemEdit[0])?$getItemEdit[0]->item_model:''); ?>">
                          	</div>
                      	</div>
                  	  	<div class="col-xs-6">
                            <div class="input-group">
                      		<label for="itemmodel">Date Purches</label>
                            	<input type="text" class="form-control show_current_date" name="datePurches" value="<?php echo e(isset($getItemEdit[0])?$getItemEdit[0]->purchase_date:''); ?>" id="datePurches" >
                            	<label id="staff_btn_box" class="input-group-addon hasArrow" style=" padding: 4px 6px; padding-right:10px; background-color:transparent; position:absolute; z-index:9; border:none !important; right:8px; margin-top:7px; border-left: 1px solid #eee !important; cursor:pointer;">
					                 <span class="glyphicon glyphicon-calendar" style="font-size:10px;"></span>
					            </label>
                            </div>
                       	</div>
                   	</div>

                  <div class="row" style="margin-top: 1px;">
                      <div class="col-xs-12 col-sm-4">
                          <div class="checkbox" style="height:35px;">
                            <label>
                              <input type="checkbox" name="warrenty"  id="warrenty" value="<?php echo e(isset($getItemEdit[0])?$getItemEdit[0]->warrenty:''); ?>" 
                             	<?php if(isset($getItemEdit[0])): ?> 
                                	<?php if($getItemEdit[0]->warrenty==1): ?>
                                    	checked
                              		<?php endif; ?>
                                <?php endif; ?>
                              > Warrenty?
                            </label>
                          </div>
                      </div>
                      	<?php if(isset($getItemEdit[0])): ?> 
	                    	<?php if($getItemEdit[0]->warrenty==1): ?>
	                        	<?php $warrenty='yes';?>
	                  		<?php endif; ?>
	                    <?php endif; ?>
                    <div class="col-xs-6 col-sm-4">
                      	<div class="form-group">
                                <input type="text" class="form-control dateWarrenty" name="datefrom" id="datefrom" placeholder="From" value="<?php echo e(isset($getItemEdit[0])?$getItemEdit[0]->warrenty_date_from:''); ?>">
                              </div>
                       </div>
                       <div class="col-xs-6 col-sm-4">
                      	<div class="form-group">
                                <input type="text" class="form-control dateWarrenty" name="dateto" id="dateto" placeholder="To" value="<?php echo e(isset($getItemEdit[0])?$getItemEdit[0]->warrenty_date_to:''); ?>">
                              </div>
                       </div>
                   </div>
                    <div class="row">
                      	<div class="col-xs-6">
                        	<div class="form-group">
                                <label for="image">Photos  <span class="optional">[Optional]</span>
                                    <span class="optional">(allow *.jpg, *.png)</span>
                                </label>
                                <input type="hidden" id="img" name="photo" value="<?php echo e(isset($getItemEdit[0])?$getItemEdit[0]->photo:''); ?>">
                                <input type="file" id="image" name="image">
                            </div>
                       </div>
                       <div class="col-xs-6">
                       		<div class="form-group">
                                <label for="docsNew">Documents   <span class="optional">[Optional]</span>
                                    <span class="optional">(allow *.PDF)</span>
                                </label>
                                <input type="hidden" id="docs" name="docs" value="<?php echo e(isset($getItemEdit[0])?$getItemEdit[0]->document:''); ?>">
                                <input type="file" id="docsNew" name="docsNew">
                            </div>
                       </div>
                   </div>
                   
                  	<div class="row">
                      	<div class="col-xs-8">
                         <label for="staff_id">Assign To Staff</label>
                          	<div class="input-group">
                               
                                <select name="staff_id" id="staff_id" class="form-control">
                                    <option value=""> -Select- </option>
                                        <?php foreach(App\Tbl_staffs::all() as $staffObj): ?>
                                        <option value="<?php echo e($staffObj->id); ?>" 
                                        <?php if(isset($getItemEdit[0])): ?>
                                        <?php if(isset($array_staff[$getItemEdit[0]->id])): ?>
                                            <?php if($array_staff[$getItemEdit[0]->id]==$staffObj->id): ?>
                                                selected
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <?php endif; ?>
                                        >
                                        <?php $arrayObj = $staffObj->getDepartmentName(); ?>
                                            <?php echo e($staffObj->staff_code); ?> : <?php echo e($staffObj->staff_name); ?> ( <?php echo e($arrayObj[$staffObj->department_id]); ?> )
                                        </option>
                                        <?php endforeach; ?>
                                </select>
                                <span class="input-group-btn">
                                <button type="button" id="addNewStaffs" class="btn btn-default"><i class="glyphicon glyphicon-plus"></i> ADD STAFF</button>
                                </span>
                            </div>
                      	</div>
                        
                  	  	
                   	</div> 
                        
                  	<div class="form-group">
                  		<label for="descriptions">Descriptions</label>
                  		<textarea class="form-control" rows="3" name="descriptions" id="descriptions"><?php echo e(isset($getItemEdit[0])?$getItemEdit[0]->description:''); ?></textarea>
                  	</div>
                  	<button type="submit" class="btn btn-info">Submit</button>
                  	<button type="reset" class="btn btn-default" class="btn btn-default" data-dismiss="modal">Close</button>
        	</form>
  		</div>      
  	</div> 
    <script>
	var warrenty='<?php echo e(isset($warrenty)?$warrenty:""); ?>';
	if(warrenty=='yes'){
		$('.dateWarrenty').show();
	}else{
		$('.dateWarrenty').hide();
	}
	//Jquery--------------------------------------------------------------
        $(function () {

				//submit new staff
				$(document).on('submit', "#addStaffForm",function (e) {
					e.preventDefault();
					var formData = new FormData(this);
					$.ajax({
						type: "POST",
						processData: false,
						contentType: false,
						url: "/addStaffFrom_inventory",
						data: formData,
						dataType: 'json',
						success: function (response) {
						   $('#newStaff').modal('hide');
						  // alert(response.id);
							$('select#staff_id').append($("<option selected></option>")
														.attr("value",response.id)
														.text(response.name)); 
						},
						error: function () {
							alert('SYSTEM ERROR, TRY LATER AGAIN');
						}
					});
				});
			
			//btn modal new staff form
			$(document).on('click', "#addNewStaffs",function () {
				$('#newStaff').modal({show:true});
			});
            $(document).on('click', ".closed",function () {
                $('#newStaff').modal('hide');
            });
			
			$('input[name="warrenty"]').on('click', function(){
				if ( $(this).is(':checked') ) {
					$('.dateWarrenty').show();
				} 
				else {
					$('.dateWarrenty').hide();
				}
			});
			
			//date from to
			
			//var date = new Date('2011', '01', '02');

// add a day
			//date.setDate(date.getYear() + 1,date.getMonth()+2,date.getDay()+3);
			
			//var days_ago=new Date().setDate(today.getDate()-90);
		//	alert(days_ago);
			$(".dateWarrenty").datetimepicker({
                value:new Date(),
                timepicker:false,
                format:'d-M-Y'
            });
            $(".show_current_date").datetimepicker({
                value:new Date(),
                timepicker:false,
                format:'d-M-Y'
            });	
			//Validate form new item
			var validator = $("form#formNewitemsubmit").validate({
					ignore: [],
					framework: 'bootstrap',
					errorPlacement: function(error, element) {
						// Append error within linked label
						$( element )
						.closest( "form" )
						.find( "label[for='" + element.attr( "id" ) + "']" )
						.append( error );
					},
					errorElement: "span",
					rules: {
						barcode: {
							required: true,
						},
						category:{
							required: true,
						},
						itemname:{
							required: true,
						},
						itemmodel:{
							required: true,
						}
					},
					messages: {
						barcode: {
							required: "(required)",
						},
						category: {
							required: "(required)",
						},
						itemname: {
							required: "(required)",
						},
						itemmodel: {
							required: "(required)",
						}
					}
				});
			//submit new item
			$(document).on('submit', "#formNewitemsubmit",function (e) {

					 	e.preventDefault();
            			var formData = new FormData(this);
						$.ajax({
								type: "POST",
								processData: false,
								contentType: false,
								url: "/item/saveNewItem",
								data: formData,
								success: function (response) {
								   $('#modelNewItem').modal('toggle');
                                    window.setTimeout(function(){ document.location.reload(true); }, 100);

								},
								error: function () {
									alert('SYSTEM ERROR, TRY LATER AGAIN');
								}
							});
				});
			
		
	});//end document ready
	
	//JavaScript--------------------------------------------------------------
       
    </script>


