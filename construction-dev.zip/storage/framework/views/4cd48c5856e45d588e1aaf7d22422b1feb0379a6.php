<?php $__env->startSection('content'); ?>
<style>
   .glyphicon-plus{
        left: 6px;
        color: #fff;
        top: -2px;
    }
    #addUsers{
        padding-left:20px;
        margin-left: -13px;
        margin-bottom: 10px;
    } 
</style>
<div class="container">
    <div class="row">
        <div class="panel panel-default summary">
            <div class="panel-body">
                <div class="col-md-12">
                    <h3>Users</h3>
                    <hr/>
                    <div class="row">
                        <div class="col-md-12">
                            <i class="glyphicon glyphicon-plus"></i>
                            <button type="button" class="btn btn-info" id="addUsers">
                                Add User</button>
                            <table class="table table-hover" id="itable">
                                <thead>
                                    <tr>
                                        <th >#</th>
                                        <th>User Name</th>
                                        <th>Email</th>
                                        <th>Role</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $x = 1;?>
                                <?php foreach(App\User::all() as $user): ?>
                                <?php $arrayobj=$user->getRoleName();?>
                                    <tr>
                                        <td><?php echo e($x); ?></td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($arrayobj[$user->role_id]); ?></td>
                                        <td style="text-align: center;">
                                            <button class="btn btn-info editUser" 
                                                    id="edit_<?php echo e($user->id); ?>">Edit</button>
                                            <button class="btn btn-danger deleteUser" 
                                                    id="delete_<?php echo e($user->id); ?>">Delete</button>
                                        </td>
                                    </tr>
                                    <?php $x++; ?>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- add new users -->
<div class="modal fade" id="addNewUsers" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog " role="document">
        <div class="modal-content ">
            <div class="modal-header">
                <button type="button"  class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Add new User</h4>
            </div>
            <div class="modal-body">

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jquery'); ?>
    <script>
        $(function () {
            
            //submit new user
            $(document).on('submit', "#addUsersForms",function (e) {
                e.preventDefault();
                var formData = new FormData(this);
                $.ajax({
                    type: "POST",
                    processData: false,
                    contentType: false,
                    url: "/createNewUser",
                    data: formData,
                    success: function (response) {
                       $('#addNewUsers').modal('toggle');
                       window.setTimeout(function(){ document.location.reload(true); }, 100);
                    },
                    error: function () {
                        alert('SYSTEM ERROR, TRY LATER AGAIN');
                    }
                });
            });
            //show model new users
            $(document).on('click', "#addUsers",function () {
                var url = "/addUser";
                $('.modal-body').load(url,function(result){
                    $('#addNewUsers').modal({show:true});
                });
            });
            //edit user 
            $(document).on('click', ".editUser",function () {
                var get_Id=$(this).attr('id');
                var id=get_Id.substr(5,get_Id.length);
                var url = "/editUser/"+id;
                $('.modal-body').load(url,function(result){
                    $('#addNewUsers').modal({show:true});
                });
            });
            //delete user
            $(document).on('click','.deleteUser',function(){
                var get_id = $(this).attr('id');
                var id = get_id.substr(7,get_id.length);
                if(confirm("Are you sure want to delete?")==true){
                    $.ajax({
                        type: "get",
                        url: "/user/deleteUser",
                        data: {user_id:id},
                        success: function (response) {
                           if(response == 'yes'){
                                swal({
                                    title:"Delete data Success",
                                    text:"This update ready!",
                                    type:"success",  
                                    timer: 1000,   
                                    showConfirmButton: false
                                });
                                window.setTimeout(function(){ document.location.reload(true); }, 1000);
                            }
                        }
                    });
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>