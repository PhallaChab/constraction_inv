<table class="table table-striped table-bordered" id="itable">
    <thead>
        <tr>
            <th>#</th>
            <th>Item Code</th>
            <th>Item Name</th>
            <th>Amount</th>
        </tr>
    </thead>
    <tbody>
        <?php $x = 1;?>
        <?php foreach($getSaleDetails as $inv): ?>
        <tr>
            <td><?php echo e($x); ?></td>
            <td><?php echo e($inv->item_code); ?></td>
            <td><?php echo e($inv->item_name); ?></td>
            <td><?php echo e($inv->qty); ?></td>
        </tr>
        <?php $x++;?>
        <?php endforeach; ?>
    </tbody>
</table>