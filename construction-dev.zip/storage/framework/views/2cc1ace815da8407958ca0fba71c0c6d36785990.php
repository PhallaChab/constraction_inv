<?php $__env->startSection('content'); ?>

<style type="text/css" media="screen">
	input{
		background: #e9ebee;
		border: 1px solid #ccc;
		border-radius: 0px !important;
	}
	.clear{
		clear:both;
	}
	tbody tr td{
		padding: 0px !important;
		vertical-align: middle !important;
	}
	.tableInput{
		/*border:1px solid #f7f7f7;*/
		border-radius: 0px !important;
	}
	.tableInput:focus{
		border: 1px solid #7f9db9;
	}
	textarea.tableInput:focus, textarea.tableInput{
		width: 277px;
	    z-index: 999;
	}
	hr{
	    background-color: #ccc;
	    height: 1px;
	    margin-top: 25px;
	}
	.closeX{
	    padding-left: 8px;
	    padding-right: 8px;
	}
	.glyphicon-th{
		padding-left: 8px;
	    padding-right: 8px;
	    background-color: #f5f6f7;
	    border: 0px solid #fff !important;
	}
	tbody tr td.newline, td.save{
		padding: 15px !important;

	}
	td a:hover{
		text-decoration: none !important;
	}
	.hr{
		background-color: #333;
		height:1px;
		margin-bottom: 2px;
	}
	.subtotal{
		margin-top: -20px;
	}
	.border-bottom{
		border-top:1px solid #ccc;
		border-bottom: 1px solid #ccc;
		margin-top: 20px;
		height: 57px;
	}
	.btn-info, .btn-basic{
		width: 100px;
	}
	select{
		height: 30px;
	}
	.currency{
		margin-bottom: 12px;
	}
	.account_box{ 
		background-color:#FFFFFF;
		position: absolute;
		z-index: 999;
		width: 130%;
		min-height:50px;
		height:200px;
		overflow:auto;
		border:1px solid #ccc;	
		display:none;
	}
	#suggesstion-box{ 
		background-color:#FFFFFF;
		position: absolute;
		z-index: 999;
		width: 130%;
		min-height:50px;
		height:200px;
		overflow:auto;
		border:1px solid #ccc;	
		display:none;
		border-radius:4px;
		box-shadow: 2px 3px 2px #ccc;
	}
	#suggesstion-box li{ cursor:pointer; }
	.list-group-item{ 
			color:#333 ; 
			padding: 5px 10px; 
			
			}
	.list-group-item:hover{ background-color:#f5f6f7; color:#666 ; border:1px dashed #ccc ; }
	
	.item_code_box{ 
		background-color:#FFFFFF;
		position: absolute;
		z-index: 999;
		width: 130%;
		min-height:50px;
		height:200px;
		overflow:auto;
		border:1px solid #ccc;	
		display:none;
	}
	.item_code_box li{ cursor:pointer; }
	
	
	
	#itemDetail .form-control {
		padding: 6px 6px;
	    border: 0px solid #ccc;
	}
	.modal-header {
		padding: 8px 15px;
		border-bottom: 1px solid #e5e5e5;
	}
	.modal-content  {
		-webkit-border-radius: 4px !important;
		-moz-border-radius: 4px !important;
		border-radius: 4px !important; 
	}
	.modal { z-index:9999;}
	.input-group .form-control {
		position: relative;
		z-index: 0;
		}
	.hasArrow{ cursor:pointer; color:#999;/*color:#099B7D;*/}
	.hasArrow:hover{ color:#ccc;}
	.table-bordered>tbody>tr>td, .table-bordered>tbody>tr>th, .table-bordered>tfoot>tr>td, .table-bordered>tfoot>tr>th, .table-bordered>thead>tr>td, .table-bordered>thead>tr>th {
		vertical-align: middle !important;
	}
	.list-group-item{ border:none;}
	.list-group-item:first-child {
		border-radius: 0px;
	}
	.orderNo{ width:25px; text-align:center;}
</style>
<div class="container">
	<div class="row">
		<div class="panel panel-default summary">
			<div class="panel-body">
				<h3>New Invoice</h3>
				<div class="clear"></div>
                <form method="post" action="/sale/insert">
                 <?php echo e(csrf_field()); ?> 
                 <div class="">
				<table class="table table-bordered tableList">
					<thead>
						<tr>
							<th colspan="10">
								<div class="row">
									<div class="col-md-12">
										<div class="col-md-2 col-xs-6"><input type="hidden" name="contact_id" id="contact_id" class="form-control" />
								            <label>To</label>
                                                <input type="text" name="contact_company" id="contact_company" class="form-control" autocomplete="off" />
                                                <label class="input-group-addon " id="contact_companyLabel" style="display:none; font-size:12px; color:#FF9E9F; position:absolute; padding: 4px 0px; padding-right:0px; background-color:transparent; z-index:9; border:none !important; right:41px; margin-top:-27px; border-left: 1px solid #eee !important;">
								                 <span class="contact_companyNew">New</span>
								                </label>
                                             <ul id="suggesstion-box" class="list-group"></ul>
								        </div>
                                        <div class="col-md-2 col-xs-6">
								            <label>Invoice #</label>
								            	<input type="text" name="invoice" id="invoice" readonly value="<?php echo e(isset($invoiceNumber)?$invoiceNumber:''); ?>" class="form-control" />
								        </div>
								       <div class="col-md-3 col-xs-6">
								       		<label>Date</label>	
								            <div class="input-group">
								                <input type="text" class="form-control show_current_date" name="dateto" />	
							                    <label class="input-group-addon">
							                      	<label class="glyphicon-calendar glyphicon"></label>
							                    </label>
								            </div>
								        </div>
							            <div class="col-md-3 col-xs-6">
							                <label>Due Date</label>
							                <div class="input-group">
								                <input type="text" class="form-control no_current_date" id="duedate" name="duedate">
								                <label class="input-group-addon">
								                  	<label class="glyphicon-calendar glyphicon"></label>
								                </label>
							                </div>
							            </div>
								        <div class="col-md-2 col-xs-12">
								            <label>Reference</label>
								            <input type="text" name="reference" id="to" class="form-control" />
								        </div>
									</div>
								</div>
								<div class="clear"></div>
								<hr/>
								<div class="currency col-md-6">
									<select name="currency">
										<option value="1">KHR Cambodian Riel</option>
										<option value="2">KHR Cambodian USA</option>
									</select>
								</div>
								<div class="currency col-md-6" style="text-align: right">
									<select name="amountsTax">
										<label>Amounts are</label>
										<option value="1">Tax Exclusive</option>
									</select>
								</div>
							</th>
						</tr>
                        
						<tr >
							<th colspan="2"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Item</th>
							<th>Description</th>
							<th width="65px">Qty</th>
							<th width="90px">Unit Price</th>
							<th width="65px">Discount</th>
							<th>Account</th>
							<th>Tax Rate</th>
							<th colspan="2">Amount KHR</th>
						</tr>
					</thead>
					<tbody>
					<?php for($i = 0; $i < 5; $i++): ?>
						<tr id="itemDetail">
							<td class="orderNo"><?php echo e($i+1); ?><!--<span class="glyphicon glyphicon-th"></span>-->
                            <input type="hidden" class="form-control tableInput " name="itemSelectedID[]" id="itemSelectedID<?php echo e($i); ?>">
                            </td>
							<td><div class="col-md-12 col-xs-12" style="padding:0px; margin:0px; min-width:100px;">
                            	<div class="input-group" style="padding:0px; margin:0px;">
                                	<input class="form-control  item_code" autocomplete="off" name="item[]" id="item<?php echo e($i); ?>">
                                    <label class="input-group-addon btnAddNewItem hasArrow" id="itemLabel<?php echo e($i); ?>" style=" padding: 4px 6px; padding-right:10px; background-color:transparent; position:absolute; z-index:9; border:none !important; right:8px; margin-top:7px; border-left: 1px solid #eee !important;">
								                 <span class="glyphicon glyphicon-triangle-bottom" style="font-size:10px;"></span>
								                </label>
                                 </div>
                            	<ul id="item_code_box<?php echo e($i); ?>" class="list-group item_code_box"></ul>
                                </div>
                            </td>
							<td><input type="text"  class="form-control tableInput" name="description[]"  id="description<?php echo e($i); ?>" style="width:180px;"></td>
							<td><input type="text"  class="form-control tableInput" name="qty[]" id="qty<?php echo e($i); ?>"></td>
							<td><input type="text"  class="form-control tableInput" name="unitp[]" id="unitp<?php echo e($i); ?>"></td>
							<td><input type="text"  class="form-control tableInput" name="disc[]" id="disc<?php echo e($i); ?>"></td>
							<td>
                            	<div class="col-md-12 col-xs-12" style="padding:0px; margin:0px; min-width:100px;">
                                    <div class="input-group" style="padding:0px; margin:0px;">
                                        <input type="text"  class="form-control tableInput account_inputbox" name="account[]" id="account<?php echo e($i); ?>">
                                        <label class="input-group-addon btnAddAccount hasArrow" id="accountLabel<?php echo e($i); ?>" style=" padding: 4px 6px; padding-right:10px; background-color:transparent; position:absolute; z-index:9; border:none !important; right:8px; margin-top:7px; border-left: 1px solid #eee !important;">
								                 <span class="glyphicon glyphicon-triangle-bottom" style="font-size:10px;"></span>
								                </label>
                                    </div>
                            		<ul id="account_box<?php echo e($i); ?>" class="list-group account_box"></ul>
                                </div>
                            
                            </td>
							<td><input type="text"  class="form-control tableInput" name="taxItem_id[]" id="tax<?php echo e($i); ?>"></td>
							<td><input type="text"  class="form-control tableInput" name="amount[]" id="amount<?php echo e($i); ?>"></td>
							<td><a href="#" class="closeX" onclick="deleteRow(this)">X</a></td>
						</tr>
					<?php endfor; ?>
					</tbody>
				</table>
                </div>
			</div>
			<div class="row">
				<div class="col-md-12 subtotal">
					<div class="col-md-6">
						<button type="button" class="addnewline" name="addnewline">Add a new line</button>
					</div>
					<div class="col-md-6">
						<div class="col-md-8" style="text-align: right;">
							<h5>Subtotal</h5>
							<h5>Tax</h5>
						</div>
						<div class="col-md-4" style="text-align: right;">
							<h6>00.0</h6>
							<h6>00.0</h6>
						</div>
						<div class="clear"></div>
						<div class="hr"></div>
					</div>
					<div class="col-md-6"></div>
					<div class="col-md-6">
						<div class="col-md-8" style="text-align: right;">
							<h3 style="font-weight: bold;">TOTAL</h3>
						</div>
						<div class="col-md-4" style="text-align: right;">
							<h4 style="font-weight: bold;">00.0</h4>
						</div>
						<div class="clear"></div>
						<div class="hr"></div>
						<div class="hr"></div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="border-bottom">
						<div class="col-md-6">
							<button type="submit" class="btn btn-info" name="save">Save</button>
						</div>
						<div class="col-md-6" style="text-align: right;">
							<button type="button" class="btn btn-basic">Cancel</button>
						</div>
					</div>
				</div>
			</div>
            </form>
		</div>
	</div>
</div>

<!-- Modal Add New Item-->
<!-- Modal Add New Item-->
<div class="modal fade" id="modelNewItem" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button"  class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">New Item</h4>
      </div>
      <div class="modal-body">
	</div>
   </div>
 </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jquery'); ?>
    <script>
	//Jquery--------------------------------------------------------------
        $(function () {
			
			//hide item code box show
			$('body').click(function(){
				$('.item_code_box').hide('');
				$('#suggesstion-box').hide();
				});
			//Validate form new item
			
			//show model new item 
			$(document).on('click', "#addNewItem",function () {
				var url = "/newItemModel";
				
				$('.modal-body').load(url,function(result){
						$('#modelNewItem').modal({show:true});
					});
				});
			
				
			//suggest item code
			function setItemToSelectBox(id,value,count){
					$('#item_code_box'+id).html('');
					if(value!='' && count<100){
							$.ajax({
												
											type: "get",
											url: "/item/autocomplete",
											data:'keyword='+value,
											beforeSend: function(){
												//$("#item"+val).css("background","#FFF no-repeat");
											},
											success: function(response){
												if(response!='false'){
													$("#item_code_box"+id).show();
													var categoryList = $('#item_code_box'+id);
															var category;
															categoryList.append($('<li class="list-group-item " style="color:#00aba9 !important;"> ').attr('id', 'addNewItem').html('<strong>+ New Item</strong>'));
															for(var i = 0, len = response.length; i < len; i++){
																category = response[i];
																categoryList.append($('<li class="list-group-item " onClick="selectedItem(\''+category.value+'\','+id+');">').attr('id', category.id).html(category.value+': '+category.item_name));
															}
												}//end if
												else{
														var categoryList = $('#item_code_box'+id);														
														categoryList.append($('<li class="list-group-item" style="color:#00aba9 !important;"> ').attr('id', 'addNewItem').html('<strong>+ New Item</strong>'));
													}
											}
											});
							}
				}
			var j=1;
			$(document).on('keyup', ".item_code",function (e) {
				   var idx =$(this).attr('id');
				   var id=idx.substr(4,idx.length);
				   var getValue=$(this).val();
				   $('#item_code_box'+id).html('');
						setItemToSelectBox(id,getValue,j);
						
				});
				var k=0;
				$(document).on('blur', ".item_code",function (e) {
						var idx =$(this).attr('id');
						var id=idx.substr(4,idx.length);
						var val =$(this).val();
						selectedItem(val,id);
				});
			var n=0;
			$(document).on('click', ".btnAddNewItem",function () {
					
				//if use open this comment
					var idx =$(this).attr('id');
						var id=idx.substr(9,idx.length);
						//$("#itemLabel"+id).show();
					
						//-------------------------------
						$('#item_code_box'+id).html('');
						 var getValue=$('#item'+id).val();
						// alert(getValue);
								if(getValue!=''){
										var value=getValue;
									}else{
										var value='showDefault';
									}
								setItemToSelectBox(id,value,n);
								n+=1;
					
				});
			//end
			//prevent enter key to submit
			 $('.tableInput').keydown(function(event){
				if(event.keyCode == 13) {
				  event.preventDefault();
				  return false;
				}
			  });
            $(".show_current_date").datetimepicker({
                value:new Date(),
                timepicker:false,
                format:'d-M-Y'
            });
            $(".no_current_date").datetimepicker({
                format:'d-M-Y',
                timepicker:false
            });
			//-----------------------------------------
			$("#contact_company").blur(function(){
				
					$("#contact_company").css({ "color": "teal", 'font-size': '120%' });
					$.ajax({
						type: "get",
						url: "/sale/checkExistContact",
						data:'contact_company='+$(this).val(),
						success: function(response){
							//alert(response);
							if(response=='no'){
									$("#contact_companyLabel").show();
								}else{
									$("#contact_companyLabel").hide();
									}
									$('#suggesstion-box').hide('');
						}
					});
				});
			
			//autocomplete-customer
			$("#contact_company").keyup(function(){
				$('#suggesstion-box').html('');
				var categoryList;
					$.ajax({
					type: "get",
					url: "/sale/autocomplete",
					data:'keyword='+$(this).val(),
					beforeSend: function(){
						$("#contact_company").css("background","#FFF no-repeat");
					},
					success: function(response){
						//alert(JSON.stringify(response));
						$("#suggesstion-box").show();
						categoryList = $('#suggesstion-box');
								var category;
								for(var i = 0, len = response.length; i < len; i++){
									category = response[i];
									categoryList.append($('<li class="list-group-item " onClick="selected_contact(\''+category.value+'\','+category.id+');">').attr('id', category.id).html(category.value));
								}
						
					}
					});
				});//end autocomplete-customer
				
			var beforeload = (new Date()).getTime();
			$("button").click(function() {
				var afterload = (new Date()).getTime();
     			var seconds = (afterload-beforeload) / 1000;
				var $btn = $(this);
				$btn.button('loading');
				// simulating a timeout
				setTimeout(function () {
					$btn.button('reset');
				}, seconds);
			})
			//-----------------------------------ACCOUNT ------------------------------------
			function setAccountToSelectBox(id,value){
					$('#account_box'+id).hide('');
					if(value!=''){
							$.ajax({
												
											type: "get",
											url: "/account/autocomplete",
											data:'keyword='+value,
											success: function(response){
												if(response!='false'){
													$("#account_box"+id).hide();
													var categoryList = $('#account_box'+id);
															var category;
															categoryList.append($('<li class="list-group-item " style="color:#00aba9 !important;"> ').attr('id', 'addNewAccount').html('<strong>+ New Account</strong>'));
															for(var i = 0, len = response.length; i < len; i++){
																category = response[i];
																categoryList.append($('<li class="list-group-item " onClick="selectedAccount(\''+category.value+'\','+id+');">').attr('id', category.id).html(category.value+': '+category.item_name));
															}
												}//end if
												else{
														var categoryList = $('#account_box'+id);														
														categoryList.append($('<li class="list-group-item" style="color:#00aba9 !important;"> ').attr('id', 'addNewAccount').html('<strong>+ New Account</strong>'));
													}
											}
											});
							}
				}
			
	});//end document ready
	
	//JavaScript--------------------------------------------------------------
        function deleteRow(btn) {
          var row = btn.parentNode.parentNode;
          row.parentNode.removeChild(row);
        }
        var counter = 4;
        jQuery('button.addnewline').click(function(event){
            event.preventDefault();
            counter++;
            var newRow = jQuery('<tr><td>'+
                counter + '</td><td class="orderNo"><input class="form-control tableInput" name="item[]" id="item' +
                counter + '"/></td><td><textarea style="height: 34px;" class="tableInput form-control" name="description[]" id="description'+
				counter+'"></textarea></td><td><input class="form-control tableInput" name="qty[]" id="qty'+
				counter+'"></td><td><input class="form-control tableInput" name="unitp[]" id="unitp'+
				counter+'"></td><td><input class="form-control tableInput" name="disc[]" id="disc'+
				counter+'"></td><td><input class="form-control tableInput" name="account[]" id="account'+
				counter+'"></td><td><input class="form-control tableInput" name="taxItem_id[]" id="tax'+
				counter+'"></td><td><input class="form-control tableInput" name="amount[]" id="amount'+
				counter+'"></td><td><a href="#" class="closeX" onclick="deleteRow(this)">X</a></td></tr>');
            jQuery('table.tableList').append(newRow);
        });
		
		//auto complete
        function selected_contact(val,id) {
			
			$("#contact_company").val(val);
			$("#contact_id").val(id);
			$("#duedate").focus();
			$("#contact_company").css({ "color": "teal", 'font-size': '150%' })
			$("#suggesstion-box").hide();
			}
		//auto complete item
		function selectedItem(val,id) {
			
			if(val!="" ){
				$.ajax({
						type: "get",
						url: "/item/show",
						data:'item_code='+val,
						success: function(response){
							if(response!='false'){
								//alert(response[0].item_code);
								$("#item"+id).val(response[0].item_code);
								$("#itemSelectedID"+id).val(response[0].id);
								$("#description"+id).val(response[0].item_name);
								$("#qty"+id).val(1);
								$("#unitp"+id).val(response[0].unit_price);
								$("#disc"+id).val(0);
								$("#account"+id).val(response[0].account_id);
								$("#taxItem_id"+id).val(response[0].tax_item_id);
								$("#amount"+id).val(response[0].unit_price);
								$("#item"+id).css({ "color": "teal"})
								$("#item_code_box"+id).hide();
								$('#item_code_box'+id).html('');
							}else{
								$("#item"+id).val('');
								$("#item_code_box"+id).hide();
								$('#item_code_box'+id).html('');
								}
						}
					});
				}
			}
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>