<?php $__env->startSection('content'); ?>
<style>
	#btnAddItem{
		margin-bottom: 10px;
	}
	input[type=number]::-webkit-inner-spin-button {
	  -webkit-appearance: none;
	}
	.select2-dropdown { border-radius: 0px;}
	.select2-container { width:100% !important;} 
	.selete-textbox{ 
		height: 28px;
    	border: 1px solid #999;
	}
	.select2-container--default .select2-selection--single {  border-radius: 0px !important; height: 34px !important;}
	.select2-container--default .select2-selection--single .select2-selection__rendered { line-height: 34px;}
	.btnadd{
		margin-top:22px;
	}
</style>
<div class="container">
    <div class="row">
        <div class="panel panel-default summary">
            <div class="panel-body">
            	
				<div class="col-sm-12 col-md-12 cover_thumbnail_2" id="">
					<h3>Request Item</h3>
                	<hr/>
					<form method="post" id="submitForm">
						<?php echo e(csrf_field()); ?>

						
						<div class="col-xs-3">
							<div class="form-group">
								<p style="margin: 0px;"><label>Item Category</label></p>
								<select name="item_id" id="item_id" class="form-control select_item_id">
									<option value="">-Select Item Category-</option>
									<?php foreach(App\ItemCategory::all() as $objCate): ?>
									<?php if($objCate->getItemList->count()>0): ?>
									<optgroup label="<?php echo e($objCate->category_name); ?>">
										<?php foreach($objCate->getItemList as $objItem): ?>
										<option value="<?php echo e($objItem->id); ?>"><?php echo e($objItem->item_name); ?></option>
										<?php endforeach; ?>
									</optgroup>
									<?php endif; ?>
									<?php endforeach; ?>
								</select>
							</div>
						</div>
						<div class="col-xs-3">
							<div class="form-group">
								<label>Quantity</label>
								<input type="number" name="item_qty" id="item_qty" class="form-control" placeholder="0">
								<span id="showMsg_stock_error"></span>
							</div>
						</div>
						
						<div class="col-xs-3">
							<div class="form-group">
					        	<button type="button" name="submit_" class="btn btnadd btn-primary submit_" id="submit_" onclick="buttonClick();">Add Item</button>
					        	<a href="/stockRequest" type="reset" class="btn btnadd btn-default" data-dismiss="modal">Back</a>
					        </div>
				        </div>
						<div class="col-md-12">
							<hr style="clear: both" />
							<table class="table table-striped table-bordered">
								<tr>
									<th>#</th>
									<th>Item Code</th>
									<th>Item Name</th>
									<th>Amount</th>
									<th>Action</th>
								</tr>
								<tbody id="showReturnInserted">
									<?php if(isset($itemID)): ?>
										<?php $x = 1; ?>
										<input type="hidden" name="invID" value="<?php echo e($itemID); ?>">
										<?php foreach($getSaleDetail as $detail): ?>
											<tr>
											<input type="hidden" name="itemId[]" value="<?php echo e($detail->id); ?>">
											<input type="hidden" name="amount[]" value="<?php echo e($detail->qty); ?>">

												<td><?php echo e($x); ?></td>
												<td><?php echo e($detail->item_code); ?></td>
												<td><?php echo e($detail->item_name); ?></td>
												<td><?php echo e($detail->qty); ?></td>
												<td><button type="button" class="btn btn-danger" onclick="deleteRow(this)">X</button></td>
											</tr>
											<?php $x++; ?>
										<?php endforeach; ?>
									<?php endif; ?>
								</tbody>
							</table>
						</div>
						<div class="col-xs-3">
							<div class="form-group">
							
								<label>Date Request</label>
								<input type="text" name="toDate" id="toDate" class="show_current_date form-control" required 
								value="<?php if(isset($itemID)): ?><?php echo e(date('d-M-Y', strtotime(isset($getSaleDetail[0])?$getSaleDetail[0]->toDate:''))); ?> <?php endif; ?>" placeholder="Date Request">
							</div>
						</div>
						<div class="col-xs-3" style="margin-top:23px;">
							<button type="submit" class="btn btn-info">Submit Invoice</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('jquery'); ?>
<script src ="<?php echo e(asset('js/select2.min.js')); ?>"></script>
<link rel="stylesheet" href="<?php echo e(asset('css/select2.css')); ?>">
	<script>
	//=======================start function================
		var count = 1;
		var count = $("#showReturnInserted").children().length;
	    function buttonClick() {
	    	count++;
	    	var item_id = $('select[name="item_id"] :selected').val();
	    	var item_qty = $("#item_qty").val();

	    	$.get("/selectItemName/"+item_id, function(data, status){
	            // alert("Data: " + data + "\nStatus: " + status);
	            var dataArray = jQuery.parseJSON(data);
	            $('#modalAddItem').modal('hide');
				$("#showReturnInserted").append(
					'<tr>'+
						'<input type="hidden" name="itemId[]" value="'+item_id+'">'+
						'<input type="hidden" name="amount[]" value="'+item_qty+'">'+
						'<td>'+count+'</td>'+
						'<td>'+dataArray.code+'</td>'+
						'<td>'+dataArray.name+'</td>'+
						'<td>'+item_qty+'</td>'+
						'<td><button type="button" class="btn btn-danger" onclick="deleteRow(this)">X</button></td>'+
					'</tr>'
				);
	        });
	    }
	    function deleteRow(btn) {
	       	var row = btn.parentNode.parentNode;
	      	row.parentNode.removeChild(row);
	    }
	    function add_itemToRoom(){
			var url = "/loadformItem";
			$('.modal-body').load(url,function(result){
				$('#modalAddItem').modal({
					show:true
				});
			});
		}

	    //===================finish function================

		$(function () {
			$(".select_item_id").select2({
			  	placeholder: "Select a Item",
			  	allowClear: true
			});
			$(".show_current_date").datetimepicker({
	            // value:new Date(),
	            timepicker:false,
	            format:'d-M-Y'
	        });
	        $(document).on('submit', "#submitForm",function (e) {
			 	e.preventDefault();
				var formData = new FormData(this);
				$.ajax({
					type: "POST",
					processData: false,
					contentType: false,
					url: "/addItemToInvoid",
					data: formData,
					success: function (response) {
						// alert(response);
						if(response!='no'){
							swal({
	                            title:"Request Item Success!",
	                            text:"Request Item Success!",
	                            type:"success",  
	                            timer: 2000,   
	                            showConfirmButton: false
	                        });
	                        window.setTimeout(function(){ 
	                        	window.location.href = "/stockRequest"
	                        },1000);
						}
					},
					error: function () {
						alert('Please Add some Item Reques!');
					}
				});
			});

		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>