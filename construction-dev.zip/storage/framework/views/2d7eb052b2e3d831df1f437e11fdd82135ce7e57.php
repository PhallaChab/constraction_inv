
<form method="post" id="addNewRoom">
	<?php echo e(csrf_field()); ?>

	<input type="hidden" value="<?php echo e(isset($showRoomid[0])?$showRoomid[0]->id:''); ?>" name="room_id" id="room_id">

	<div class="form-group row">
		<label class="col-md-3 col-form-label">Room name</label>
		<div class="col-md-9">
		    <input class="form-control" type="text" id="roomName" name="roomName" placeholder="Room Name" value="<?php echo e(isset($showRoomid[0])?$showRoomid[0]->condo_name:''); ?>">
		</div>
	</div>
	<div class="form-group row">
		<label class="col-md-3 col-form-label">Select Floor</label>
		  <div class="col-md-9">
		    <select name="floor" required class="form-control">
	   			<option value="" style="display: none;">--Select--</option>
	   			<?php foreach($condoFloor as $floor): ?>
	   			<option value="<?php echo e($floor->id); ?>" 
	   				<?php if(isset($showRoomid[0])): ?>
	   					<?php if($showRoomid[0]->floor_id==$floor->id): ?>
	   						selected
	   					<?php endif; ?>
	   				<?php endif; ?>
	   			>
				   <?php echo e($floor->floor); ?>

				</option>
	   			<?php endforeach; ?>
	   		</select>
		</div>
	</div>
    <button type="submit" class="btn btn-info">Save changes</button>
    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
</form>

<script>
	$(function(){
		$(document).on('submit', "#addNewRoom",function (e) {
		 	e.preventDefault();
			var formData = new FormData(this);
			$.ajax({
				type: "POST",
				processData: false,
				contentType: false,
				url: "/addNewRooms",
				data: formData,
				success: function (response) {
				   $('#modalNewRoom').modal('toggle');
				   window.setTimeout(function(){ document.location.reload(true); }, 100);
				},
				error: function () {
					alert('SYSTEM ERROR, TRY LATER AGAIN');
				}
			});
		});
	});
</script>