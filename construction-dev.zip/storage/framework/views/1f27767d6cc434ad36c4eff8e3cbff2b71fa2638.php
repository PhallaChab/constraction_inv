<?php $__env->startSection('content'); ?>
<style type="text/css" media="screen">
	.tax_rate, .glyphicon{
		font-size: 16px;
	}
	span p{
		margin-left:22px;
	}
	.general{
		padding-bottom: 20px;
	}
</style>
<div class="container">
	<div class="row">
		<div class="panel panel-default summary">
			<div class="panel-body">
				<div class="col-md-6">
					<h3>Organisation</h3>
					<hr/>
					
					<div class="user general">
						<span class="glyphicon glyphicon-star-empty"></span>
						<span>
							<a href="" class="tax_rate">Users</a>
							<p>Manage who has access to your organisation.</p>
						</span>
					</div>

					<div class="rate general">
						<span class="glyphicon glyphicon-star-empty"></span>
						<span>
							<a href="/taxRates" class="tax_rate">Tax Rates</a>
							<p>Add, edit and delete the tax rates you want to use.</p>
						</span>
					</div>
				</div>

				<div class="col-md-6">
					<h3>Reports</h3>
					<hr/>
					<div class="user general">
						<span class="glyphicon glyphicon-star-empty"></span>
						<span>
							<a href="/chartofaccount" class="tax_rate">Chart of Accounts</a>
							<p>Add, edit, archive, delete, import or export your accounts.</p>
						</span>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>