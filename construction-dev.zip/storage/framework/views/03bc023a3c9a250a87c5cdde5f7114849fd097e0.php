<nav class="navbar navbar-default navbar-static-top">
    <div class="container">
    <div class="navbar-header">
      <button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".js-navbar-collapse">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
            MWGROUP 
        </a>
    </div>


    <div class="collapse navbar-collapse js-navbar-collapse">
      <ul class="nav navbar-nav">
      	<?php if( Auth::check() ): ?>
        
         <?php foreach(App\Tbl_menuses::all() as $parents): ?>
                <li class="dropdown">
                	<a href="<?php echo e($parents->link); ?>"  <?php echo ($parents->subMenus->count())?'href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"':''; ?>>
                		<?php echo e(strtoupper($parents->name)); ?> <span class="<?php echo e(($parents->subMenus->count())?'caret':''); ?>"></span>
                    </a>
                	<ul class="dropdown-menu">
                 	<?php if($parents->subMenus->count()): ?>
						<?php foreach($parents->subMenus as $obj): ?>
                        	<li><a href="<?php echo e($obj->url); ?>"><?php echo e($obj->sub_name); ?></a></li>
                        <?php endforeach; ?>
                	<?php endif; ?>
                    </ul>
                </li>
                <?php endforeach; ?>
        <?php endif; ?>
      </ul>
 <!-- Right Side Of Navbar -->
                <ul class="nav navbar-nav navbar-right">
                    <!-- Authentication Links -->
                    <?php if(Auth::guest()): ?>
                        <li><a href="<?php echo e(url('/login')); ?>">Login</a></li>
                    <?php else: ?>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                            </a>

                            <ul class="dropdown-menu" role="menu">
                                <li>
                                    <a href="#" id="changePass"><i class="fa fa-btn fa-lock"></i>
                                        Change Password</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('/logout')); ?>"><i class="fa fa-btn fa-sign-out"></i>Logout</a>
                                </li>
                            </ul>
                        </li>
                    <?php endif; ?>
                </ul>
    </div>
    <!-- /.nav-collapse -->
</div>
</nav>
<div class="container-fluid">
	<div class="row sub_menu">
    	<div class="container">
        	<h4 class="company-name" style="padding-top: 6px;"><strong><span style="color: teal">1Residence Inventory</span></strong> </h4>
        </div>
    </div>
</div>
<div class="container">
               
</div>

