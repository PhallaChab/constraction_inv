<?php $__env->startSection('content'); ?>
<style type="text/css">
#chart-1 {
	min-width: 150px;
	max-width: 100%;
	margin: 0 auto;
}
.highcharts-credits{ display:none;}
</style>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                  
                  		<?php  $bordercolor=array_reverse($array_color);?>
                        <div class="row">
                  		<?php foreach($array_dashboard as $k=>$v): ?>
                        
                  			<div class="col-md-2 col-sm-2 col-xs-6" style="background-color:#<?php echo e($array_color[$k]); ?>; height:100px;  ">
                        		
                                <h2 align="center" style="position:absolute; bottom:25px; margin-left:35%; color:#fff;"><?php echo e($array_data[$k]); ?></h2>
                        	</div>
                        
                        <?php endforeach; ?>
                        </div>
                        <div class="row">
                        <?php foreach($array_dashboard as $k=>$v): ?>
                            <div class="col-md-2 col-sm-2 col-xs-6" style=" height:50px; ">
                            	<h4 align="center" style="color:#999; margin-top:2px;"><?php echo e(strtoupper($v)); ?></h4>
                            </div>
                        <?php endforeach; ?>
                        </div>
                        
                        <div class="row">
                        	<div id="chart-1"></div>
                            
                        </div>
                  </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jquery'); ?>

<script src ="<?php echo e(asset('js/highcharts.js')); ?>"></script>
<script src ="<?php echo e(asset('js/highcharts-more.js')); ?>"></script>

 	<script>
	$(document).ready(function(e) {
       			Highcharts.chart('chart-1', {
					colors: ['#aa4339', '#226765'],
					chart: {
						type: 'column'
						
					},
					title: {
						text: 'Monthly Report'
					},
					subtitle: {
						text: 'Inventory and Staff Entry '
					},
					xAxis: {
						categories: [
							'Jan',
							'Feb',
							'Mar',
							'Apr',
							'May',
							'Jun',
							'Jul',
							'Aug',
							'Sep',
							'Oct',
							'Nov',
							'Dec'
						],
						crosshair: true
					},
					yAxis: {
						min: 0,
						title: {
							text: 'Amount'
						}
					},
					tooltip: {
						headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
						pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
							'<td style="padding:0"><b>{point.y:.1f} mm</b></td></tr>',
						footerFormat: '</table>',
						shared: true,
						useHTML: true
					},
					plotOptions: {
						column: {
							pointPadding: 0.2,
							borderWidth: 0
						}
					},
					series: [{
						name: 'Staff',
						data: [49.9, 71.5, 106.4, 129.2, 144.0, 176.0, 135.6, 148.5, 216.4, 194.1, 95.6, 54.4]
				
					}, {
						name: 'Inventory',
						data: [83.6, 78.8, 98.5, 93.4, 106.0, 84.5, 105.0, 104.3, 91.2, 83.5, 106.6, 92.3]
				
					}]
				});
		});
	</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>