<?php $__env->startSection('content'); ?>
	<style type="text/css" media='screen'>
		.modal-dialog{
			width: 70%;
		}
		@media (min-width: 320px) and (max-width: 768px) {
			.modal-dialog{
				width: 95%;
			}
		}
		@media (min-width: 320px) and (max-width: 568px) {
			.modal-dialog{
				width: 94%;
			}
		}
		#addnewAccount{
			margin-bottom: 20px;
		}
		.tab-content{ background-color:#fff; padding:15px; border:1px solid #ddd; border-top:none; }
		.glyphicon-search{
			right: 23px;
    		top: 3px;
		}
		table.dataTable thead > tr > th{
			padding-left: 8px !important;
		}
		.selectedEditRow{
			cursor: pointer;
		}
		.glyphicon-plus{
			left: 18px;
		    color: #fff;
		    top: -8px;
		}
		.btn-info{
			padding-left:20px;
		}
	</style>
	<div class="container">
		<div class="row">
			<div class="panel panel-default summary">
				<div class="panel-body">
					<div class="col-md-12">
						<h3>Chart Of Account</h3>
						<hr/>
						<i class="glyphicon glyphicon-plus"></i><button type="button" class="btn btn-info" id="addnewAccount">Add Account</button>
						
						<div class="row">
					    	<div class="col-md-12">
		                        <ul class="nav nav-tabs">
		                        	<li class="active">
		                        		<a href="#tabAll" class='alltab' data-toggle="tab">All Account</a>
		                        	</li>
		                        <?php foreach(App\TblAccountCategory::all() as $accountCat): ?>
		                            <li><a href="#tab<?php echo e($accountCat->id); ?>" data-toggle="tab">
		                            	<?php echo e($accountCat->category_name); ?></a>
		                            </li>
		                        <?php endforeach; ?>
		                        </ul>
			                    <div class="tab-content">
			                     	<div class="tab-pane fade in active" id="tabAll">
			                        	<table class="table table-hover" id="itable">
                                            <thead>
                                                <tr>
                                                    <th style="width: 12%;"><input type="checkbox" name="">&nbsp;&nbsp;Code</th>
                                                    <th style="width: 50%;">Name</th>
                                                    <th style='text-align:center'>Type</th>
                                                    <th style='text-align:center'>Tax Rate</th>
                                                    <th style='text-align:center'>YTD</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                              	<?php foreach(App\TblAccounting::all() as $grandChild): ?>
                                                    <tr id="edit_<?php echo e($grandChild->id); ?>" class="selectedEditRow">
                                                        <td ><input type="checkbox" name="">&nbsp;&nbsp;<?php echo e($grandChild->account_code); ?></td>
                                                        <td>
                                                        	<b><?php echo e($grandChild->account_name); ?></b><br/>
                                                            <span><?php echo e($grandChild->account_description); ?></span>
                                                        </td>
                                                        <td style='text-align:center'>
                                                        	<?php echo e($grandChild->ChildAccounting->account_type_name); ?>

                                                        </td>
                                                        <td style='text-align:left'>
                                                        	<?php echo e($grandChild->ChildTaxRate->tax_name); ?>

                                                        	(<?php echo e($grandChild->ChildTaxRate->total_tax_rate); ?>%)
                                                        </td>
                                                        <td style='text-align:center'>00.0</td>
                                                    </tr>
                                                 <?php endforeach; ?>
                                			</tbody>
                                         </table>
			                      	</div>
			                    	<?php echo $__env->make('accounting.listAccounting', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			                    </div>
					        </div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- addNewAccounting model -->
	<div class="modal fade" id="addNewAccounting" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  	<div class="modal-dialog " role="document">
	    	<div class="modal-content ">
	      		<div class="modal-header">
	        		<button type="button"  class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        		<h4 class="modal-title" id="myModalLabel">Add new Accounting</h4>
	      		</div>
		      	<div class="modal-body">

				</div>
	   		</div>
	 	</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jquery'); ?>
	<script src ="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
	<script src ="<?php echo e(asset('js/dataTables.bootstrap.js')); ?>"></script>
	<link rel="stylesheet" href="<?php echo e(asset('css/dataTables.bootstrap.css')); ?>">

    <script>
        $(function () {
        	//-----
        	$('.table-hover').dataTable( {
				"bPaginate": true
			});
        	//-------
        	$( ".dataTables_filter > label" ).append( "<span class='glyphicon glyphicon-search'></span>" );
			//show model new item 
			$(document).on('click', "#addnewAccount",function () {
				var url = "/addAccount";
				$('.modal-body').load(url,function(result){
					$('#addNewAccounting').modal({show:true});
				});
			});
			//---------------

			$(document).on('click', ".selectedEditRow",function () {
				var get_Id=$(this).attr('id');
				var id=get_Id.substr(5,get_Id.length);
				var url = "/editAccountModel/"+id;
				$('.modal-body').load(url,function(result){
						$('#addNewAccounting').modal({show:true});
					});
			});
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>