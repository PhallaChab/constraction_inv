<?php $__env->startSection('content'); ?>

<style type="text/css" media="screen">
	input{
		background: #e9ebee;
		border: 1px solid #ccc;
		
		border-radius: 0px !important;
	}
	.clear{
		clear:both;
	}
	tbody tr td{
		padding: 0px !important;
		vertical-align: middle !important;
	}
	.tableInput{
		border:1px solid #f7f7f7;
		border-radius: 0px !important;
	}
	.tableInput:focus{
		border: 1px solid #7f9db9;
	}
	textarea.tableInput:focus, textarea.tableInput{
		width: 277px;
	    z-index: 999;
	}
	hr{
	    background-color: #ccc;
	    height: 1px;
	    margin-top: 25px;
	}
	.closeX{
	    padding-left: 8px;
	    padding-right: 8px;
	}
	.glyphicon-th{
		padding-left: 8px;
	    padding-right: 8px;
	    background-color: #f5f6f7;
	    border: 0px solid #fff !important;
	}
	tbody tr td.newline, td.save{
		padding: 15px !important;

	}
	td a:hover{
		text-decoration: none !important;
	}
	.hr{
		background-color: #333;
		height:1px;
		margin-bottom: 2px;
	}
	.subtotal{
		margin-top: -20px;
	}
	.border-bottom{
		border-top:1px solid #ccc;
		border-bottom: 1px solid #ccc;
		margin-top: 20px;
		height: 57px;
	}
	.btn-info, .btn-basic{
		margin-top:10px;
		width: 100px;
	}
	select{
		height: 30px;
	}
	.currency{
		margin-bottom: 12px;
	}
	#suggesstion-box{ 
		background-color:#FFFFFF;
		position: absolute;
		z-index: 999;
		width: 100%;	
	}
	#suggesstion-box li{ cursor:pointer; }
	.list-group-item{ color:#45474D !important; padding: 5px 10px;}
	.list-group-item:hover{ background-color:#f7f7f7;}
</style>
<div class="container">
	<div class="row">
		<div class="panel panel-default summary">
			<div class="panel-body">
				<h3>New Invoice</h3>
				<div class="clear"></div>
				<table class="table table-bordered tableList">
					<thead>
						<tr>
							<th colspan="10">
								<div class="row">
									<div class="col-md-12">
									<form method="post">
										<div class="col-md-2 col-xs-12">
								            <label>To</label>
                                            <div class="input-group">
                                                <input type="text" name="contact_company" id="contact_company" class="form-control" />
                                                
                                             </div>
                                             <ul id="suggesstion-box" class="list-group"></ul>
								        </div>
								       <div class="col-md-3 col-xs-12">
								       		<label>Date</label>
								            <div class="input-group">
								                <input type="text" class="form-control show_current_date" name="date" />	
							                    <label class="input-group-addon">
							                      	<label class="glyphicon-calendar glyphicon"></label>
							                    </label>
								            </div>
								        </div>
							            <div class="col-md-3 col-xs-12">
							                <label>Due Date</label>
							                <div class="input-group">
								                <input type="text" class="form-control no_current_date" id="duedate" name="duedate">
								                <label class="input-group-addon">
								                  	<label class="glyphicon-calendar glyphicon"></label>
								                </label>
							                </div>
							            </div>
							            <div class="col-md-2 col-xs-12">
								            <label>Invoice #</label>
								            <input type="text" name="invoice" id="to" class="form-control" />
								        </div>
								        <div class="col-md-2 col-xs-12">
								            <label>Reference</label>
								            <input type="text" name="reference" id="to" class="form-control" />
								        </div>
								    </form>
									</div>
									
								</div>
								<div class="clear"></div>
								<hr/>
								<div class="currency col-md-6">
									<select name="currency">
										<option value="">KHR Cambodian Riel</option>
										<option value="">KHR Cambodian USA</option>
									</select>
								</div>
								<div class="currency col-md-6" style="text-align: right">
									<select name="amountsTax">
										<label>Amounts are</label>
										<option value="">Tax Exclusive</option>
									</select>
								</div>
							</th>
						</tr>
						<tr >
							<th colspan="2"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Item</th>
							<th>Description</th>
							<th width="65px">Qty</th>
							<th width="90px">Unit Price</th>
							<th width="65px">Disc %</th>
							<th>Account</th>
							<th>Tax Rate</th>
							<th colspan="2">Amount KHR</th>
						</tr>
					</thead>
					<tbody>
					<?php for($i = 0; $i < 5; $i++): ?>
						<tr>
							<td><span class="glyphicon glyphicon-th"></span></td>
							<td><input class="form-control tableInput" name="item" id="item"></td>
							<td><textarea style="height: 34px;" class="tableInput form-control" name="description" id="description"></textarea></td>
							<td><input class="form-control tableInput" name="qty" id="qty"></td>
							<td><input class="form-control tableInput" name="unitp" id="unitp"></td>
							<td><input class="form-control tableInput" name="disc" id="disc"></td>
							<td><input class="form-control tableInput" name="account" id="account"></td>
							<td><input class="form-control tableInput" name="tax" id="tax"></td>
							<td><input class="form-control tableInput" name="amount" id="amount"></td>
							<td><a href="#" class="closeX" onclick="deleteRow(this)">X</a></td>
						</tr>
					<?php endfor; ?>
					</tbody>
				</table>
			</div>
			<div class="row">
				<div class="col-md-12 subtotal">
					<div class="col-md-6">
						<button type="button" class="addnewline" name="addnewline">Add a new line</button>
					</div>
					<div class="col-md-6">
						<div class="col-md-8" style="text-align: right;">
							<h5>Subtotal</h5>
							<h5>Tax</h5>
						</div>
						<div class="col-md-4" style="text-align: right;">
							<h6>00.0</h6>
							<h6>00.0</h6>
						</div>
						<div class="clear"></div>
						<div class="hr"></div>
					</div>
					<div class="col-md-6"></div>
					<div class="col-md-6">
						<div class="col-md-8" style="text-align: right;">
							<h3 style="font-weight: bold;">TOTAL</h3>
						</div>
						<div class="col-md-4" style="text-align: right;">
							<h4 style="font-weight: bold;">00.0</h4>
						</div>
						<div class="clear"></div>
						<div class="hr"></div>
						<div class="hr"></div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="border-bottom">
						<div class="col-md-6">
							<button type="button" class="btn btn-info" name="save">Save</button>
						</div>
						<div class="col-md-6" style="text-align: right;">
							<button type="button" class="btn btn-basic">Cancel</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('jquery'); ?>
    <script>
        $(function () {
            $(".show_current_date").datetimepicker({
                value:new Date(),
                timepicker:false,
                format:'d-M-Y'
            });
            $(".no_current_date").datetimepicker({
                format:'d-M-Y',
                timepicker:false
            });
			//-----------------------------------------
			$("#add_customer").click(function(){
				alert('asdf');
				});
			
			//autocomplete
			$("#contact_company").keyup(function(){
				$('#suggesstion-box').html('');
				var categoryList;
					$.ajax({
					type: "get",
					url: "/search/autocomplete",
					data:'keyword='+$(this).val(),
					beforeSend: function(){
						$("#contact_company").css("background","#FFF no-repeat");
					},
					success: function(response){
						//alert(JSON.stringify(response));
						$("#suggesstion-box").show();
						categoryList = $('#suggesstion-box');
								var category;
								for(var i = 0, len = response.length; i < len; i++){
									category = response[i];
									categoryList.append($('<li class="list-group-item " onClick="selectCountry(\''+category.value+'\');">').attr('id', category.id).html(category.value));
								}
						
						//$("#suggesstion-box").html(tr);
						//$("#contact_company").css("background","#FFF");
					}
					});
				});
			
	});
        function deleteRow(btn) {
          var row = btn.parentNode.parentNode;
          row.parentNode.removeChild(row);
        }
        var counter = 1;
        jQuery('button.addnewline').click(function(event){
            event.preventDefault();
            counter++;
            var newRow = jQuery('<tr><td><span class="glyphicon glyphicon-th"' +
                counter + '"></span></td><td><input class="form-control tableInput" name="item" id="item"' +
                counter + '"/></td><td><textarea style="height: 34px;" class="tableInput form-control" name="description" id="description"></textarea></td><td><input class="form-control tableInput" name="qty" id="qty"></td><td><input class="form-control tableInput" name="unitp" id="unitp"></td><td><input class="form-control tableInput" name="disc" id="disc"></td><td><input class="form-control tableInput" name="account" id="account"></td><td><input class="form-control tableInput" name="tax" id="tax"></td><td><input class="form-control tableInput" name="amount" id="amount"></td><td><a href="#" class="closeX" onclick="deleteRow(this)">X</a></td></tr>');
            jQuery('table.tableList').append(newRow);
        });
		
		//auto complete
        function selectCountry(val) {
			
			$("#contact_company").val(val);
			$("#contact_company").css({ "color": "teal", 'font-size': '150%' })
			$("#suggesstion-box").hide();
			}
			
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>