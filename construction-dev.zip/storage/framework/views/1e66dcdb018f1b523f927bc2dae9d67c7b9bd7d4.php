<form method="post" id="addStaffForm" action="/addStaffForm">
	<?php echo e(csrf_field()); ?>

	<div class="form-group row">
		<label class="col-md-3 col-form-label">Name</label>
		<div class="col-md-9">
		    <input class="form-control" type="text" id="fullName" name="fullName" placeholder="Full Name">
		</div>
	</div>
	<div class="form-group row">
		<label class="col-md-3 col-form-label">Saff Code</label>
		  <div class="col-md-9">
		    <input class="form-control" type="code" id="code" name="code" placeholder="3199">
		</div>
	</div>
	<div class="form-group row">
		<label class="col-md-3 col-form-label">Department</label>
		  	<div class="col-md-9">
		   		<select name="department" required class="form-control">
		   			<option value="">--Select--</option>
		   			<?php foreach(App\Tbl_department::all() as $dep): ?>
		   			<option value="<?php echo e($dep->id); ?>"><?php echo e($dep->department_name); ?></option>
		   			<?php endforeach; ?>
		   		</select>
			</div>
	</div>
	<div class="form-group row">
		<label for="mobile" class="col-md-3 col-form-label">Phone Number</label>
		<div class="col-md-9">
		    <input class="form-control" type="text" id="mobile" name="mobile" placeholder="Personal Phone">
		</div>
	</div>
	<div class="form-group row">
		<label class="col-md-3 col-form-label">Gender</label>
		  	<div class="col-md-9">
		   		<select name="gender" required class="form-control">
		   			<option value="">--Select--</option>
		   			<option value="1">Male</option>
		   			<option value="2">Female</option>
		   		</select>
			</div>
	</div>
	<div class="form-group row">
		<label class="col-md-3 col-form-label">Position</label>
		  <div class="col-md-9">
		    <input class="form-control" type="text" id="position" name="position" placeholder="IT Support">
		</div>
	</div>
    <button type="submit" class="btn btn-primary">Save changes</button>
    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
</form>