<?php $__env->startSection('content'); ?>
	<style type="text/css" media="screen">

	</style>
	<div class="container">
		<div class="row">
			<div class="panel panel-default summary">
				<div class="panel-body">
					<div class="col-md-12">
						<button class="btn btn-info" id="btnNewInventory">New Inventroy</button>
						<hr/>
						<?php echo $__env->make('inventory.inventoryList', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
  <!--Modal new inventory-->
<div class="modal fade" id="modelNewInventory" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button"  class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">New Item</h4>
      </div>
      	<div class="modal-body">
		</div>
   </div>
 </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('jquery'); ?>
    <script>
	
        $(function () {
       		$(document).on('click', "#btnNewInventory",function () {
				var url = "/newItemModel";
				$('.modal-body').load(url,function(result){
						$('#modelNewInventory').modal({show:true});
					});
				});

		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>