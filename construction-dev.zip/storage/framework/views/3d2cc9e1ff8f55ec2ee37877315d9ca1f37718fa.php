
<table class="table table-striped table-bordered">
	<tr>
		<th>#</th>
		<th>Item Code</th>
		<th>Item Name</th>
		<th>Amount</th>
		<th>Responder</th>
		<th>Date</th>
	</tr>
	<tbody >
		<?php 
		$roomID=1;
		$x=1; $totalAmount=0;
		foreach(App\tbl_sale_invs::where('room_id',$roomid)->orderBy('item_id','desc')->get() as $objInv){

					$arrayStaff=$objInv->getStaff($objInv->staff_id);
					$arrayItem=$objInv->getItem($objInv->item_id);
					$array_item_stock_id=$objInv->getItem_stock($objInv->item_id);

					$totalAmount+=$objInv->quantity;
					//echo $array_item_stock[$objInv->id];

			echo'	<tr class="removeInventory'.$objInv->id.'_'.$array_item_stock_id[$objInv->id].'">
					<td>'.$x.'</td>
					<td>'.$arrayItem[0][$objInv->item_id].'</td>
					<td>'.$arrayItem[1][$objInv->item_id].'</td>
					<td>'.$objInv->quantity.'</td>
					<td>'.$arrayStaff[$objInv->staff_id].'</td>
					<td>'.date("d M, Y",strtotime($objInv->toDate)).'</td>
					
				</tr>';
				 $x++;
			}
			echo '<tr>
					<th></th>
					<th></th>
					<th>Total</th>
					<th>'.$totalAmount.'</th>
					<th></th>
					<th></th>
					
				</tr>';
		?>
	</tbody>

</table>