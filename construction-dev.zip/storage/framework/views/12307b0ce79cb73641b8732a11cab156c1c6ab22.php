<?php $__env->startSection('content'); ?>
<style type="text/css">
    .input-group-addon {
			min-width:250px;
			text-align:right !important;
		}
	.noti{ height:10px;}
</style>
<div class="container">
<div class="panel panel-default summary">
  <div class="panel-body">
    	<div class="col-md-8 col-md-offset-2">
        <h3>Setup Company <span class="sub_text">Fill Your Company Information</span></h3><hr>
            <form method="post" action="/company_action"  accept-charset="utf-8" id="callLog_form">
                <?php echo e(csrf_field()); ?> 
                <input type="hidden" name="userid" value="<?php echo e(Auth::user()->id); ?>">
                <input type="hidden" name="company_id" value="<?php echo e(isset($data)?trim($data->id):''); ?>">
                <div class="input-group  col-md-12">
                    <span class="input-group-addon">Company Name</span>
                    <input type="text" name="company" id="company" class="form-control" required value="<?php echo e(isset($data)?trim($data->name):''); ?>"/>
                </div>
                <p class="fg-red noti" align="right">
                <?php if($errors->has('company')): ?> 
                    <?php echo e($errors->first('company')); ?>

                <?php endif; ?>
    			</p>
                <div class="input-group  col-md-12">
                    <span class="input-group-addon">Address</span>
                    <input type="text" name="address" id="address" class="form-control" required value="<?php echo e(isset($data)?trim($data->address):''); ?>"/>
                </div>
               <p class="fg-red noti" align="right"></p>
                <div class="input-group  col-md-12">
                    <span class="input-group-addon">Phone Number</span>
                    <input type="text" name="phoneNumber" id="phoneNumber" class="form-control" required value="<?php echo e(isset($data)?trim($data->number):''); ?>"/>
                </div>
               <p class="fg-red noti" align="right"></p>
                <div class="input-group  col-md-12">
                    <span class="input-group-addon">What does your company do?</span>
                    <input type="text" name="company_task" id="company_task" class="form-control" required  value="<?php echo e(isset($data)?trim($data->company_task):''); ?>"/>
                   
                </div>
              <p class="fg-red noti" align="right"></p>
                <button class="btn btn-info " type="submit" name="save">Submit</button>
            </form>
    	</div>
	</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>