
	<table class="table table-hover" id="inventTbl">
        <thead>
            <tr>
                <th>Item Code</th>
                <th>Item Category</th>
                <th>Item Name</th>
                <th>Item Model</th>
                <th>Warrenty</th>
                <th>Warrenty Date</th>
                <th>Picture</th>
                <th>Price</th>
                <th>Description</th>
            </tr>
        </thead>
        <tbody>
        	<?php foreach(App\Tbl_item::all() as $item): ?>
              	<tr>
              		<td><?php echo e($item->item_code); ?></td>
              		<td><?php echo e($item->getItemCateogry['category_name']); ?></td>
              		<td><?php echo e($item->item_name); ?></td>
              		<td><?php echo e($item->item_model); ?></td>
              		<td><?php echo e($item->warrenty); ?></td>
              		<td><?php echo e($item->warrenty_date); ?></td>
              		<td><img src="uploads/<?php echo e($item->photo); ?>" alt="" width="100px"></td>
              		<td><?php echo e($item->price); ?></td>
              		<td><?php echo e($item->description); ?></td>
                </tr>
       		<?php endforeach; ?>
        </tbody>
    </table>