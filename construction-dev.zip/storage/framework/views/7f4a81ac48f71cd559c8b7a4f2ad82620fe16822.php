<?php $__env->startSection('content'); ?>

	<div class="container">
		<div class="row">
			<div class="panel panel-default summary">
				<div class="panel-body">
					<div class="col-md-12">
						<button class="btn btn-info" id="btnNewInventory">New Inventroy</button>
						<hr/>
						<?php echo $__env->make('inventory.inventoryList', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
  <!--Modal new inventory-->
<div class="modal fade" id="modelNewInventory" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button"  class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"><span id="showTitle"></span> Inventory </h4>
      </div>
      	<div class="modal-body">
		</div>
   </div>
 </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('jquery'); ?>
    <script>
	
        $(function () {
        	// $('#modelNewInventory').modal({backdrop: 'static', keyboard: false}) ;

       		$(document).on('click', "#btnNewInventory",function () {
				var url = "/newItemModel";
				$('.modal-body').load(url,function(result){
					$('#modelNewInventory').modal({show:true});
				});
				$('#showTitle').html("New");
			});

			$(document).on('click',".selectItem",function(){
				var get_Id=$(this).attr('id');
				var id=get_Id.substr(8,get_Id.length);
				var url = "/editInventory/"+id;
				$('.modal-body').load(url,function(result){
					$('#modelNewInventory').modal({show:true});
				});
				$('#showTitle').html("Edit");
			});
			$(document).on('click', ".deleteItem",function () {
				var get_Id=$(this).attr('id');
				var idx=get_Id.substr(10,get_Id.length);
				var picture = $("#photo").val();
				if(confirm("Are you sure want to delete?")==true){
					$.ajax({
						type: "get",
						url: "/deleteItem",
						data: {item_id:idx,image:picture},
						success: function (response) {
						   	if(response == 'yes'){
								swal({
									title:"Delete data Success",
									text:"This update ready!",
									type:"success",  
									timer: 3000,   
									showConfirmButton: false
								});
								window.setTimeout(function(){ document.location.reload(true); }, 1000);
							}
						}
					});
				}
			});

		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>