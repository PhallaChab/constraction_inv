<?php $__env->startSection('content'); ?>
<style>
    .col-md-4{
        margin-right:0px;
        margin-left: 0px;
        background: linear-gradient(#c4c5c6,#f5f7f8);
        border: 1px solid #ccc;
        text-align: center;
        color: #555;
        cursor: pointer;
    }
    div.col-md-4{
        box-shadow: 0 1px 3px rgba(221,221,221,0.5);
        margin-bottom: 20px;
        padding: 15px;
    }
    .col-md-4:hover{
        color:#00aba9;
    }  
    .active{
         color:#00aba9 !important;
    }
</style>
<div class="container">
    <div class="row">
        <div class="panel panel-default summary">
            <div class="panel-body">
                <div class="col-md-12">
                    <?php
                        $status_arr = array(
                            '0'=>'Waiting Aprroval',
                            '1'=>'Approved',
                            '2'=>'Listing All'
                        );
                    ?>
                    <?php for( $i=0;$i< 3;$i++ ): ?>
                        <a href="/request_management/<?php echo e($i); ?>" >
                            <?php if(isset($status)): ?>
                                <?php if($status==$i): ?>
                                    <?php $active = 'active';?>
                                <?php else: ?>
                                    <?php $active = '';?>
                                <?php endif; ?>
                            <?php endif; ?>
                            <div class="col-md-4 <?php echo e(isset($active)?$active:''); ?>">
                                <p><?php echo e($status_arr[$i]); ?></p>
                                <h3><?php echo e($countRequest[$i]); ?></h3>
                            </div>
                        </a>
                    <?php endfor; ?>
                    <?php if(isset($status)): ?>
                        <?php for($j=0;$j< 3;$j++): ?>
                            <?php if($status==$j): ?>
                                <h3><?php echo e($status_arr[$j]); ?></h3>
                            <?php endif; ?>
                        <?php endfor; ?>
                    <?php else: ?>
                        <h3>Request Management</h3>
                    <?php endif; ?>
                    <hr/>
                    <div class="row">
                        <div class="col-md-12">
                            <table class="table table-striped table-bordered" id="itable">
                                <thead>
                                    <tr>
                                        <th >#</th>
                                        <th>Invoid Code</th>
                                        <th>Date Request</th>
                                        <th width="137px">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $x = 1;?>
                                <?php foreach($getSaleInv as $invoice): ?>
                                    <tr class="hideApprove<?php echo e($invoice->id); ?>">
                                        <td><?php echo e($x); ?></td>
                                        <td>Inv-<?php echo e(date('Ym')); ?><?php echo e($invoice->invoid_code); ?></td>
                                        <td><?php echo e(date('M d, Y', strtotime($invoice->toDate))); ?></td>
                                        <td>
                                            <a href="#" onclick="viewAction(<?php echo e($invoice->id); ?>);" >View</a> |
                                            <?php if($invoice->status==1): ?>
                                            	<span class="glyphicon glyphicon-ok" style="color:green"></span>
                                            <?php else: ?>
                                           	<a style="font-size: 12px" name="approve" class="label label-info" onclick="approvAction(<?php echo e($invoice->id); ?>);">Approve</a>
                                           	<?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php $x++;?>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
<div class="modal fade" id="modalViewItem" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Item Requested</h4>
      </div>
        <div class="modal-body">
            
        </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jquery'); ?>
<script>
    function viewAction($id){
        var url = "/getSaleDetailview/"+$id;
        $('.modal-body').load(url,function(result){
            $('#modalViewItem').modal({
                show:true,
            });
        });
    }
    function approvAction($id){
    	var url = "/approvrequest/"+$id;
	    $.get(url, function(data, status){
	        //alert("Data: " + data + "\nStatus: " + status);
	        if(data=='yes'){
	        	swal({
                    title:"Item request has been approved!",
                    text:"Approved Success!",
                    type:"success",  
                    timer: 1000,   
                    showConfirmButton: false
                });
                window.setTimeout(function(){ document.location.reload(true); },1000);
	        }
	        
	    });
    }
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>