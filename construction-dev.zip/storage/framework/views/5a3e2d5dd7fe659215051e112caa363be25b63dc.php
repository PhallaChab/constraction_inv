<?php $__env->startSection('content'); ?>
	<style type="text/css" media="screen">
		.glyphicon-search{
			right: 23px;
			top: 3px;
		}
		table.dataTable thead .sorting{
			background:none !important;
		}
		table.dataTable thead .sorting_asc{
			background:none !important;
		}
		th.sorting_asc{
			width: 13px !important;
	    	padding-right: 0px !important;
		}
		td.sorting_1 > input{
			float: right;
	    	margin-left: 10px !important;
		}
		th:nth-child(2), th:nth-child(3){
	    	padding-left: 8px !important;
		}
	</style>
	<div class="container">
		<div class="row">
			<div class="panel panel-default summary">
				<div class="panel-body">
					<div class="col-md-12">
						<h3>Inventory</h3>
						<hr/>
						<button type="button" class="btn btn-info" id="addNewItem">
							<i class="glyphicon glyphicon-plus"></i> 
							New Item</button>
						<table class="table table-hover" id="inventTbl">
					        <thead>
					            <tr>
					                <th style="width: 19px;padding-right: 9px;">
					                	<input type="checkbox" name="checkInventory[]" class="checkInventory"></th>
					                <th>Item Code</th>
					                <th width="40%">Item Name</th>
					                <th style="text-align: center;">Cost Price</th>
					                <th style="text-align: center;">Sale Price</th>
					                <th style="text-align: center;">Quantity</th>
					            </tr>
					        </thead>
					        <tbody>
                            <?php $arrayInventory=array();?>
					        <?php foreach(App\Tbl_item_detail::all() as $inventory): ?>
					        	<?php if($inventory->getItem->company_id==Auth::user()->company_id): ?>
                               
                                   <?php  $arrayInventory[$inventory->item_id][$inventory->inventory_type]=$inventory->unit_price;?>

	                                <?php if($inventory->inventory_type==1): ?>
					              	<tr>
					                    <td>
					                    	<input type="checkbox" name="checkInventory[]" class="checkInventory" value="<?php echo e($inventory->id); ?>"></td>
					                    <td><?php echo e($inventory->getItem->item_code); ?></td>
					                    <td><?php echo e($inventory->getItem->item_name); ?></td>
					                    <td style="text-align: center;">
					                    	<?php echo e($arrayInventory[12][1]); ?>

					                    </td>
					                    <td style="text-align: center;"><?php echo e($inventory->unit_price); ?></td>
					                    <td style="text-align: center;"><?php echo e($inventory->qty); ?></td>
					                </tr>
					                <?php endif; ?>
                                <?php endif; ?>
				            <?php endforeach; ?>
					        </tbody>
					    </table>
					</div>
				</div>
			</div>
		</div>
	</div>
    <pre>
    <?php print_r($arrayInventory);?>
	<!-- add new tax rates model -->
	<div class="modal fade" id="modelNewItem" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  	<div class="modal-dialog " role="document">
	    	<div class="modal-content ">
	      		<div class="modal-header">
	        		<button type="button"  class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        		<h4 class="modal-title" id="myModalLabel">Add new TaxRates</h4>
	      		</div>
		      	<div class="modal-body">

				</div>
	   		</div>
	 	</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jquery'); ?>
	<script src ="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
	<script src ="<?php echo e(asset('js/dataTables.bootstrap.js')); ?>"></script>
	<link rel="stylesheet" href="<?php echo e(asset('css/dataTables.bootstrap.css')); ?>">

    <script>
        $(function () {
        	//-----
        	$('.table-hover').dataTable( {
				"bPaginate": false
			});
			//add search icon
			$( ".dataTables_filter > label" ).append( "<span class='glyphicon glyphicon-search'></span>" );

			//show model new item 
			$(document).on('click', "#addNewItem",function () {
				var url = "/addNewItem/"+2;
				$('.modal-body').load(url,function(result){
					$('#modelNewItem').modal({show:true});
				});
			});

		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>