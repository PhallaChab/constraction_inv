<?php $__env->startSection('content'); ?>
<style type="text/css" media="screen">
	.glyphicon-plus{
		left: 6px;
	    color: #fff;
	    top: -2px;
	}
	#addNewRate{
		padding-left:20px;
		margin-left: -13px;
	    margin-bottom: 10px;
	}
	table#itable thead tr{
		background: #e9ebee;
	}
	.glyphicon-search{
		right: 23px;
		top: 3px;
	}
	.glyphicon-remove{
		margin-top:8px;
	}
	tbody.tbodyrate tr{
		border-bottom: 2px solid #ddd;
	}
	tr.last_tr{
		border-bottom: none !important;
	}
	input[type=number]::-webkit-inner-spin-button {
	    -webkit-appearance: none;
	}
	.percent{
		float: right;
		margin-top: -26px;
		margin-right: 3px;
	}
	#name{
		width: 46% !important;
	}
	tr.tableAddnew{
		border: none;
	}
	span.text{
		font-size: 12px;
	}
	#tax_name{
		width: 37.9%;
	}
	input.total_rate{
		height: 21px;
	    padding: 0px;
	    background: none !important;
	    border: none;
	    margin-top:10px;
	}
	label.textTotal{
		margin-top:8px;
	}
	table.dataTable thead > tr > th{
		padding-left: 10px !important;
	}
	.selectRow{
		cursor: pointer;
	}
	table.dataTable thead .sorting_asc{
		background: none !important;
	}
	.glyphicon-lock, .checkbox{
		float: right;
	}
</style>
<div class="container">
	<div class="row">
		<div class="panel panel-default summary">
			<div class="panel-body">
				<div class="col-md-12">

					<h3>Tax Rates</h3>
					<hr/>
					<form method="post" action="/deleteTaxRate">
						<?php echo e(csrf_field()); ?>

						<div class="row">
					    	<div class="col-md-12">
					    	<i class="glyphicon glyphicon-plus"></i><button type="button" class="btn btn-info " id="addNewRate">Add TaxRates</button>
					    		<table class="table table-hover" id="itable">
	                                <thead>
	                                    <tr>
	                                        <th style="width: 19px;padding-right: 9px;"><input type="checkbox" name="checkbox[]" class="checkbox"></th>
	                                        <th>Name</th>
	                                        <th style="text-align: center;">Tax Rate</th>
	                                        <th style="text-align: center;">Accounts using this Tax Rate</th>
	                                    </tr>
	                                </thead>
	                                <tbody>
		                                <?php foreach($getTaxtRate as $rate): ?>
		                                  	<tr>
		                                        <td>
		                                        	<?php echo ($rate->tax_status==1)? 
			                                        	'<span class="glyphicon glyphicon-lock"></span>': 
			                                        	'<input type="checkbox" name="checkTaxRate[]" class="checkbox" value="'.$rate->id.'">'; ?></td>
		                                        <td id="editrate_<?php echo e($rate->id); ?>" class="selectRow">&nbsp;&nbsp;<?php echo e($rate->tax_name); ?></td>
		                                        <td style="text-align: center;"> 
		                                        	<span id="trTaxRate<?php echo e($rate->id); ?>"><?php echo e($rate->total_tax_rate); ?></span>%</td>
		                                        <td id="editrate_<?php echo e($rate->id); ?>" class="selectRow" style="text-align: center;">
		                                        	<?php echo e($rate->taxUsingAccounting->count()); ?></td>
		                                    </tr>
		                                <?php endforeach; ?>
	                                </tbody>
	                            </table>
					    	</div>
					    </div>
				    </form>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- add new tax rates model -->
	<div class="modal fade" id="addNewTaxRate" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  	<div class="modal-dialog " role="document">
	    	<div class="modal-content ">
	      		<div class="modal-header">
	        		<button type="button"  class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        		<h4 class="modal-title" id="myModalLabel">Add new TaxRates</h4>
	      		</div>
		      	<div class="modal-body">

				</div>
	   		</div>
	 	</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jquery'); ?>
	<script src ="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
	<script src ="<?php echo e(asset('js/dataTables.bootstrap.js')); ?>"></script>
	<link rel="stylesheet" href="<?php echo e(asset('css/dataTables.bootstrap.css')); ?>">

    <script>
        $(function () {
        	//-----
        	$('.table-hover').dataTable( {
				"bPaginate": false
			});
			//appen button delete in row table
        	$( ".dataTables_wrapper > div:nth-child(1) > div:nth-child(1)" ).append( "<button type='submit' class='btn btn-danger' name='delete'>Delete</button>" );

			//add search icon
			$( ".dataTables_filter > label" ).append( "<span class='glyphicon glyphicon-search'></span>" );
			//show model new item 
			$(document).on('click', "#addNewRate",function () {
				var url = "/addTaxRate";
				$('.modal-body').load(url,function(result){
					$('#addNewTaxRate').modal({show:true});
				});
			});
			//---------------

			$(document).on('click', ".selectRow",function () {
				var get_Id=$(this).attr('id');
				var id=get_Id.substr(9,get_Id.length);
				var url = "/editTaxRate/"+id;
				//alert(id);
				$('.modal-body').load(url,function(result){
					$('#addNewTaxRate').modal({show:true});
				});
			});
			//----------------------------
			$(document).on('click', '.glyphicon-remove', function (e) {
				e.preventDefault();
				var idx=$(this).attr('id');
				var id=idx.substr(6,idx.length);
				var tax_id = $("#taxtRate_id").val();
				$.ajax({
				    url:"/tax_component/delete_tax_component", 
				    data: { component_id:id, taxRateid:tax_id},
				    success: function(data) {
				    	if(data!='false'){
							$('#remove'+id).closest('tr').remove();
							$('#lblValue').val(data+"%");
							$("#trTaxRate"+tax_id).html(data);
						//	alert(data+'-'+tax_id);
				    	}else{
				    		$('.message').html("<span style='color:red;float:right'>Cannot Remove!</span>");
				    	}
				   	},
				   	type: 'GET'
				});

			    
			});
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>