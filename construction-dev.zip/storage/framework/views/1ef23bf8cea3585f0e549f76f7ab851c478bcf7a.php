
<style type="text/css">
select option { padding: 6px;}
.alert { margin:0px; padding:5px 15px;}
</style>
<div class="alert alert-warning"><h3 align="center">Enter Inventory Information Below:</h3></div>
<div class="panel panel-default" style="border:none; padding:15px 25px;">
<div class="panel-body" >
		<form method="post" id="formNewitemsubmit">
			<?php echo e(csrf_field()); ?> 
                        		<div class="form-group">
                                    <label for="barcode">Category</label>
                                   	<select name="category" id="category" class="form-control">
                                    	<option value=""> -Select- </option>
                                        	<?php foreach(App\ItemCategory::all() as $cateoryObj): ?>
                                        	<option value="<?php echo e($cateoryObj->id); ?>"><?php echo e($cateoryObj->category_name); ?></option>
                                            <?php endforeach; ?>
                                    </select>
                                  </div>
                                  <div class="form-group">
                                    <label for="itemname">Item Name</label>
                                    <input type="text" class="form-control" name="itemname" id="itemname" placeholder="Item Name">
                                  </div>
                                  <div class="form-group">
                                    <label for="itemmodel">Model</label>
                                    <input type="text" class="form-control" name="itemmodel" id="itemmodel" placeholder="Item Model">
                                  </div>
                                  <div class="form-group">
                                    <label for="barcode">Barcode</label>
                                    <input type="text" class="form-control" name="barcode" id="barcode" placeholder="Item Barcode">
                                  </div>
                                  
                                  <div class="form-group">
                                    <label for="image">Photos</label>
                                    <input type="file" id="image" name="image">
                                    <p class="help-block">(allow *.jpg, *.gif, *.png)</p>
                                  </div>
                                  <div class="checkbox">
                                    <label>
                                      <input type="checkbox" name="warrenty" id="warrenty" value="yes"> Warrenty?
                                    </label>
                                  </div>
                                  
                                  <div class="form-group">
                                    <label for="price">Price</label>
                                    <input type="text" class="form-control" name="price" id="price" placeholder="Item Price">
                                  </div>
                                  <div class="form-group">
                                  	<label for="descriptions">Descriptions</label>
                                  	<textarea class="form-control" rows="3" name="descriptions" id="descriptions"></textarea>
                                  </div>
                                  <button type="submit" class="btn btn-info">Submit</button>
                                  <button type="reset" class="btn btn-default">Close</button>
                        </form>
       
  </div>      
  </div> 
    <script>
	//Jquery--------------------------------------------------------------
        $(function () {
			//Validate form new item
			var validator = $("form#formNewitemsubmit").validate({
					ignore: [],
					framework: 'bootstrap',
					errorPlacement: function(error, element) {
						// Append error within linked label
						$( element )
						.closest( "form" )
						.find( "label[for='" + element.attr( "id" ) + "']" )
						.append( error );
					},
					errorElement: "span",
					rules: {
						barcode: {
							required: true,
							remote: {
										url: "/item/existItemCode",
										type: "get"
									}
						},
						category:{
							required: true,
						},
						itemname:{
							required: true,
						},
						itemmodel:{
								required: true,
							}
					},
					messages: {
						barcode: {
							required: "(required)",
							remote:" (This code is exist!)"
						},
						category: {
							required: "(required)",
						},
						itemname: {
							required: "(required)",
						},
						itemmodel: {
							required: "(required)",
						}
					}
				});
			//submit new item
			$(document).on('submit', "#formNewitemsubmit",function (e) {
					 	e.preventDefault();
            			var formData = new FormData(this);
						$.ajax({
								type: "POST",
								processData: false,
								contentType: false,
								url: "/item/saveNewItem",
								data: formData,
								success: function (response) {
								   $('#modelNewItem').modal('toggle');
                                    window.setTimeout(function(){ document.location.reload(true); }, 100);

								},
								error: function () {
									alert('SYSTEM ERROR, TRY LATER AGAIN');
								}
							});
				});
			
		
	});//end document ready
	
	//JavaScript--------------------------------------------------------------
       
    </script>


