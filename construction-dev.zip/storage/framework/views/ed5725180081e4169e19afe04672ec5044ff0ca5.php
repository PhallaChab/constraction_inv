<?php $__env->startSection('content'); ?>
<style type="text/css" media="screen">
	.tax_rate, .glyphicon{
		font-size: 16px;
	}
	span p{
		margin-left:22px;
	}
	.general{
		padding-bottom: 20px;
	}
</style>
<div class="container">
	<div class="row">
		<div class="panel panel-default summary">
			<div class="panel-body">
				<div class="col-md-6">
					<h3>Organize</h3>
					<hr/>
					<div class="general">
						<span class="glyphicon glyphicon-star-empty"></span>
						<span>
							<a href="/newUser" class="tax_rate">System Users</a>
							<p>Manage all users in Company.</p>
						</span>
					</div>
					<div class="general">
						<span class="glyphicon glyphicon-star-empty"></span>
						<span>
							<a href="/department" class="tax_rate">Department</a>
							<p>Manage all department in Company.</p>
						</span>
					</div>

					<div class="general">
						<span class="glyphicon glyphicon-star-empty"></span>
						<span>
							<a href="/categoryItem" class="tax_rate">Item Category</a>
							<p>Add, edit and delete the category you want to use.</p>
						</span>
					</div>
				</div>

				<div class="col-md-6">
					<h3>Reports</h3>
					<hr/>
					<div class="general">
						<span class="glyphicon glyphicon-star-empty"></span>
						<span>
							<a href="/itemunit" class="tax_rate">Item Unit</a>
							<p>Add Item unit</p>
						</span>
					</div>
					<div class="general">
						<span class="glyphicon glyphicon-star-empty"></span>
						<span>
							<a href="/supplier" class="tax_rate">Supplier Profile</a>
							<p>Add/edit/delete supplier profile</p>
						</span>
					</div>
					<div class="general">
						<span class="glyphicon glyphicon-star-empty"></span>
						<span>
							<a href="/receiver" class="tax_rate">Receiver Profile</a>
							<p>Add/edit/delete reveiver profile</p>
						</span>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>