<?php foreach(App\TblAccountCategory::all() as $parents): ?>
<div class="tab-pane" id="tab<?php echo e($parents->id); ?>">
    <table class="table table-hover" id="eachTab<?php echo e($parents->id); ?>">
        <thead>
            <tr>
                <th style="width: 70px;"><input type="checkbox" name="">&nbsp;&nbsp;Code</th>
                <th style="width: 360px;">Name</th>
                <th style='text-align:center'>Type</th>
                <th style='text-align:center'>Tax Rate</th>
                <th style='text-align:center'>YTD	</th>
            </tr>
        </thead>
        <tbody>
        <?php if($parents->getAccountType->count()): ?>
            <?php foreach($parents->getAccountType as $child): ?>
                <!--Listing Accounting-->
                <?php if($child->grandChildAccounting->count()): ?>
                    <?php foreach($child->grandChildAccounting as $grandChild): ?>
                        <tr id="edit_<?php echo e($grandChild->id); ?>" class="selectedEditRow">
                            <td><input type="checkbox" name="">&nbsp;&nbsp;<?php echo e($grandChild->account_code); ?></td>
                            <td><b><?php echo e($grandChild->account_name); ?></b><br/>
                                <span><?php echo e($grandChild->account_description); ?></span>
                            </td>
                            <td style='text-align:center'><?php echo e($grandChild->ChildAccounting->account_type_name); ?></td>
                            <td style='text-align:center'>
                                <?php echo e($grandChild->ChildTaxRate->tax_name); ?>

                                (<?php echo e($grandChild->ChildTaxRate->total_tax_rate); ?>%)
                            </td>
                            <td style='text-align:center'>00.0</td>
                        </tr>
                     <?php endforeach; ?>
                <?php endif; ?>
              
            <?php endforeach; ?>
        <?php endif; ?>
		</tbody>
    </table>
</div>
<?php endforeach; ?>