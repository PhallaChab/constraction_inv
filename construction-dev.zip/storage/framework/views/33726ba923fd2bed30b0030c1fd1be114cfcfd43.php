<?php $__env->startSection('content'); ?>
<style type="text/css" media="screen">
	.addbtnContact{
		text-align: right;
	}
	.rightTable{
		height: 780px;
		border-left: 1px solid #ccc;
	}
	.headerTable{
		height: 50px;
		border-bottom: 1px solid #ccc;
		background: #fff;
	}

	.inputSearch{
		background-color: #fff;
    	border: 1px solid #ddd;
    	height: 34px;
    	font-size: 14px;
    	margin-left: 20px;
    	padding-left:30px;
	}
	.searchform{
		margin-top:8px;
	}
	.glyphicon-search{
		left:44px;
		color:#757575;
	}
	ul.navbar-nav li a:hover, .nav .open>a:focus{
		background: none;
	}
	ul.option{
		top: 37px;
	}
	.list-group-item:first-child{
		border-top: none;
	}
	.list-group-item:first-child, .list-group-item:last-child{
		border-radius:0px;
	}
	li.list-group-item{
	    border-right: none;
	    border-top: 1px solid #ccc;
	    border-bottom: 1px solid #ccc;
	}
	tr td{
		background: white;
	}
	tr th{
		background: #e9ebee;
	}
	.panel-footer{
		border: 1px solid #ddd;
	    border-bottom-right-radius: 0px;
	    border-bottom-left-radius: 0px;
	    margin-left: -30px;
	    margin-right: -16px;
	    border-bottom: none;
	}
	.glyphicon-plus{
		left: 18px;
	    color: #fff;
	}
	.btn-info{
		padding-left:20px;
	}
	/*table style scroll*/
	.table-fixed thead {
	  width: 100%;
	}
	.table-fixed tbody {
	  height: 696px;
	  overflow-y: auto;
	  width: 100%;
	}
	.table-fixed thead, .table-fixed tbody, .table-fixed tr, .table-fixed td, .table-fixed th {
	  display: block;
	}
	.table-fixed tbody td, .table-fixed thead > tr> th {
	  float: left;
	  border-bottom-width: 0;
	}
	input[type=checkbox]{
		margin:0 0 0;
	}
	/*end*/
</style>
<div class="container">
	<div class="row">
		<div class="panel panel-default summary">
			<div class="panel-body">
				<div class="col-md-12">
					<div class="row">
						<div class="col-md-6">
							<h4>Contact</h4>
						</div>
						<div class="col-md-6">
							<div class="row addbtnContact">
								<i class="glyphicon glyphicon-plus"></i><button type="submit" name="addcontact" class="btn btn-info" data-toggle="modal" data-target="#exampleModal">Add Contact</button>
							</div>
						</div>
					</div>
					<div class="row" style="border: 1px solid #ccc; background-color: #fff;">
						<div class="contact_form">
							<div class="col-md-3">
								<ul class="list-group" style="margin-left:-16px">
								<?php foreach(App\Tbl_menuses::find(4)->subMenus as $obj): ?>
								  	<li class="list-group-item ">
								  		<a href="/contactMenu/<?php echo e($obj->id); ?>">
								  			<?php echo e($obj->sub_name); ?>

								  			<!-- count each sub menu if(id=4) echo count_all else count_each_submenu-->
								  			<?php echo e(($obj->id==4)? $countall : $obj->menuContact->count()); ?> 
								  		</a>
								  	</li>
								 <?php endforeach; ?>
						                       
								</ul>
							</div>
							<div class="col-md-9">
								<div class="row rightTable" style="margin-left: -30px;">
									<div class="headerTable col-md-12">
										<div class="col-md-4">
											<ul class="nav navbar-nav">
										        <li class="dropdown ">
										          	<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Option <span class="caret"></span></a>
										          	<ul class="dropdown-menu option">
										            	<li><a href="#">Add to Group</a></li>
										            	<li><a href="#">Merge</a></li>
										           	</ul>
										        </li>
										        <li><a href="#">Edit</a></li>
										    </ul>
										</div>
									    <div class="col-md-8" style="text-align: right;">
											<div class="form-group searchform">
										        <span>No items selected</span>
										          	<i class="glyphicon glyphicon-search"></i>
										          	<input type="text" class="inputSearch" placeholder="Search..." />
										        <!-- <span>Sort by name</span> -->
										    </div>
									    </div>
									</div>
									<!-- header table -->
									<table class="table table-fixed">
							          	<thead>
							            	<tr>
							              		<th class="col-xs-3"><input type="checkbox" name="">&nbsp;&nbsp;Contact</th>
							              		<th class="col-xs-3">Email</th>
							              		<th class="col-xs-3" style="text-align: center;">You owe them</th>
							              		<th class="col-xs-3" style="text-align: center;">They owe you</th>
							            	</tr>
							          	</thead>
							          	<tbody>
							          	 <?php if(isset($getContectMenu)): ?>
											<?php foreach($getContectMenu as $contact): ?>
								            <tr>
								              	<td class="col-xs-3">
								              		<span><input type="checkbox"/> 
								              			&nbsp;&nbsp;<?php echo e($contact->contact_company); ?>

								              		</span>
								              	</td>
								              	<td class="col-xs-3"><?php echo e($contact->email); ?></td>
								              	<td class="col-xs-3" style="text-align: center;">__</td>
								              	<td class="col-xs-3" style="text-align: center;">__</td>
								            </tr>
								            <?php endforeach; ?>
								        <?php endif; ?>
								        </tbody>
									</table>
								</div>
								<div class="panel-footer"><?php echo e(isset($countbymenu)); ?> Total item</div>
							</div>
							<!-- div col-md-9 -->
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  	<div class="modal-dialog" role="document">
	    <div class="modal-content">
	      	<div class="modal-header">
	        	<h5 class="modal-title" id="exampleModalLabel">Add New Contact</h5>
	        	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          	<span aria-hidden="true">&times;</span>
	        	</button>
	      	</div>
	      	<div class="modal-body">
	        	<form method="post" id="addContactForm" action="/addContactForm">
	        		<?php echo e(csrf_field()); ?> 
		        	<div class="form-group row">
						<label for="contactName" class="col-md-3 col-form-label">Contact name</label>
					  	<div class="col-md-9">
					    	<input class="form-control" type="text" id="contactName" name="contactName" placeholder="Contact Name">
					  	</div>
					</div>
					<div class="form-group row">
						<label class="col-md-3 col-form-label">Full Name</label>
						<div class="col-md-9">
						    <input class="form-control" type="text" id="fullName" name="fullName" placeholder="Full Name">
						</div>
					</div>
					<div class="form-group row">
						<label class="col-md-3 col-form-label">Email</label>
						  <div class="col-md-9">
						    <input class="form-control" type="email" id="email" name="email" placeholder="info@gmail.com">
						</div>
					</div>
					<div class="form-group row">
						<label for="mobile" class="col-md-3 col-form-label">Mobile Phone</label>
						<div class="col-md-9">
						    <input class="form-control" type="text" id="mobile" name="mobile" placeholder="Personal Phone">
						</div>
					</div>
					<div class="form-group row">
						<label for="deskphone" class="col-md-3 col-form-label">DeskPhone</label>
						  <div class="col-md-9">
						    <input class="form-control" type="text" id="deskphone" name="deskphone" placeholder="Company Phone">
						</div>
					</div>
					<div class="form-group row">
						<label class="col-md-3 col-form-label">Website</label>
						  <div class="col-md-9">
						    <input class="form-control" type="text" id="website" name="website" placeholder="www.abc.com">
						</div>
					</div>
					<div class="form-group row">
						<label class="col-md-3 col-form-label">Address</label>
						  <div class="col-md-9">
						    <textarea class="form-control" type="text" id="address" name="address" placeholder="Phnom Penh"></textarea>
						</div>
					</div>
			        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
			        <button type="submit" class="btn btn-primary">Save changes</button>
	            </form>
	      	</div>
	      	
	    </div>
  	</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('jquery'); ?>
    <script>
        $(function () {
			//Validate form contact
			var validator = $("form#addContactForm").validate({
				ignore: [],
				framework: 'bootstrap',
				errorPlacement: function(error, element) {
					// Append error within linked label
					$( element )
					.closest( "form" )
					.find( "label[for='" + element.attr( "id" ) + "']" )
					.append( error );
				},
				errorElement: "span",
				rules: {
					contactName: {
						required: true
					},
					mobile:{
						required: true
					},
					deskphone:{
						required: true
					}
				},
				messages: {
					contactName: {
						required: "(Required)"
					},
					mobile: {
						required: "(Required)"
					},
					deskphone: {
						required: "(Required)"
					}
				}
			});
		});
	</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>