<?php 
	$array_gender=array("1"=>"Male","2"=>"Female");
?>
<form method="post" id="addStaffForm" action="/addStaffForm">
	<?php echo e(csrf_field()); ?>

	<input type="hidden" value="<?php echo e(isset($getSelectEdit[0])?$getSelectEdit[0]->id:''); ?>" name="staff_id" id="staff_id">

	<div class="form-group row">
		<label class="col-md-3 col-form-label">Name</label>
		<div class="col-md-9">
		    <input class="form-control" type="text" id="fullName" name="fullName" placeholder="Full Name" value="<?php echo e(isset($getSelectEdit[0])?$getSelectEdit[0]->staff_name:''); ?>">
		</div>
	</div>
	<div class="form-group row">
		<label class="col-md-3 col-form-label">Saff ID</label>
		  <div class="col-md-9">
		    <input class="form-control" type="number" id="code" name="code" placeholder="0000" maxlength="4" min="4" value="<?php echo e(isset($getSelectEdit[0])?$getSelectEdit[0]->staff_code:''); ?>">
		</div>
	</div>
	<div class="form-group row">
		<label class="col-md-3 col-form-label">Department</label>
		  	<div class="col-md-9">
		   		<select name="department" required class="form-control">
		   			<option value="">--Select--</option>
		   			<?php foreach(App\Tbl_department::all() as $dep): ?>
		   			<option value="<?php echo e($dep->id); ?>"
		   				<?php if(isset($getSelectEdit[0])): ?>
					   		<?php if($getSelectEdit[0]->department_id==$dep->id): ?> 
					   			selected
					   		<?php endif; ?>
					   <?php endif; ?>
					   >
					   <?php echo e($dep->department_name); ?>

					</option>
		   			<?php endforeach; ?>
		   		</select>
			</div>
	</div>
	<div class="form-group row">
		<label for="mobile" class="col-md-3 col-form-label">Phone Number</label>
		<div class="col-md-9">
		    <input class="form-control" type="text" id="mobile" name="mobile" placeholder="Phone Number" value="<?php echo e(isset($getSelectEdit[0])?$getSelectEdit[0]->phone_number:''); ?>">
		</div>
	</div>
	<div class="form-group row">
		<label class="col-md-3 col-form-label">Gender</label>
		  	<div class="col-md-9">
		   		<select name="gender" required class="form-control">
                <option value="">-Select-</option>
                <?php foreach($array_gender as $ks=>$vs){?>
                	<option value="<?=$ks?>" <?php if(isset($getSelectEdit[0])){ if($getSelectEdit[0]->gender==$ks){ echo 'selected'; }}?> ><?=$vs?></option>
                <?php }?>
		   		
		   		</select>
			</div>
	</div>
	<div class="form-group row">
		<label class="col-md-3 col-form-label">Position</label>
		  <div class="col-md-9">
		    <input class="form-control" type="text" id="position" name="position" placeholder="IT Support" value="<?php echo e(isset($getSelectEdit[0])?$getSelectEdit[0]->position:''); ?>">
		</div>
	</div>
    <button type="submit" class="btn btn-primary">Save changes</button>
    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
</form>

<script>
	//submit new item
	$(function(){
		$(document).on('submit', "#addStaffForm",function (e) {
		 	e.preventDefault();
			var formData = new FormData(this);
			$.ajax({
				type: "POST",
				processData: false,
				contentType: false,
				url: "/addStaffForm",
				data: formData,
				success: function (response) {
				   $('#newStaff').modal('toggle');
				   window.setTimeout(function(){ document.location.reload(true); }, 100);
				},
				error: function () {
					alert('SYSTEM ERROR, TRY LATER AGAIN');
				}
			});
		});
	});
</script>