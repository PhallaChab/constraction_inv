<nav class="navbar navbar-default navbar-static-top">
    <div class="container">
    <div class="navbar-header">
      <button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".js-navbar-collapse">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
        <a class="navbar-brand" href="{{ url('/') }}">
            MWGROUP 
        </a>
    </div>


    <div class="collapse navbar-collapse js-navbar-collapse">
      <ul class="nav navbar-nav">
      	@if( Auth::check() )
        
         @foreach(App\Tbl_menuses::all() as $parents)
                <li class="dropdown">
                	<a href="{{ $parents->link }}"  {!! ($parents->subMenus->count())?'href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"':'' !!}>
                		{{ strtoupper($parents->name) }} <span class="{{ ($parents->subMenus->count())?'caret':'' }}"></span>
                    </a>
                	<ul class="dropdown-menu">
                 	@if($parents->subMenus->count())
						@foreach($parents->subMenus as $obj)
                        	<li><a href="{{ $obj->url }}">{{ $obj->sub_name }}</a></li>
                        @endforeach
                	@endif
                    </ul>
                </li>
                @endforeach
        @endif
      </ul>
 <!-- Right Side Of Navbar -->
                <ul class="nav navbar-nav navbar-right">
                    <!-- Authentication Links -->
                    @if (Auth::guest())
                        <li><a href="{{ url('/login') }}">Login</a></li>
                    @else
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                {{ Auth::user()->name }} <span class="caret"></span>
                            </a>

                            <ul class="dropdown-menu" role="menu">
                                <li>
                                    <a href="#" id="changePass"><i class="fa fa-btn fa-lock"></i>
                                        Change Password</a>
                                </li>
                                <li>
                                    <a href="{{ url('/logout') }}"><i class="fa fa-btn fa-sign-out"></i>Logout</a>
                                </li>
                            </ul>
                        </li>
                    @endif
                </ul>
    </div>
    <!-- /.nav-collapse -->
</div>
</nav>
<div class="container-fluid">
	<div class="row sub_menu">
    	<div class="container">
        	<h4 class="company-name" style="padding-top: 6px;"><strong><span style="color: teal">1Residence Inventory</span></strong> </h4>
        </div>
    </div>
</div>
<div class="container">
               
</div>

