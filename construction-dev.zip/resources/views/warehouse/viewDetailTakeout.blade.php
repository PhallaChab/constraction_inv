<form method="post" id="takeoutstock">
    {{ csrf_field() }}
    <table class="table table-striped table-bordered" id="itable">
        <thead>
            <tr>
                <th>#</th>
                <th>Item Code</th>
                <th>Item Name</th>
                <th>Amount</th>
            </tr>
        </thead>
        <tbody>
            <?php $x = 1;?>
            @foreach($getSaleDetails as $inv)
            <tr>
                <input type="hidden" name="itemid[]" value="{{$inv->item_id}}">
                <input type="hidden" name="saleInvid[]" value="{{$inv->sale_inv_id}}">
                <input type="hidden" name="qty[]" value="{{$inv->qty}}">
                <td>{{ $x }}</td>
                <td>{{ $inv->item_code }}</td>
                <td>{{ $inv->item_name }}</td>
                <td>{{ $inv->qty }}</td>
            </tr>
            <?php $x++;?>
            @endforeach
        </tbody>
    </table>
    <div class="form-group row">
        <div class="col-md-6">
            <input type="text" class="form-control show_current_date" name="dateDelever" id="dateDelever" required>
        </div>
        <div class="col-md-3">
            <button type="submit" class="btn btn-info" name="submit">Take Out</button>
        </div>
    </div>
</form>
<script>
$(function(){
		
        $(".show_current_date").datetimepicker({
            value:new Date(),
            timepicker:false,
            format:'d-M-Y'
        }); 
});
</script>