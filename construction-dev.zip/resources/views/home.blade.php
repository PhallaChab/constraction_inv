@extends('layouts.app')

@section('content')
<style type="text/css">
#chart-1 {
	min-width: 150px;
	max-width: 100%;
	margin: 0 auto;
}
.highcharts-credits{ display:none;}
	
div.bhoechie-tab-container{
  z-index: 10;
  background-color: #ffffff;
  padding: 0 !important;
  border-radius: 0px;
  -moz-border-radius: 0px;
  border:1px solid #ddd;
  margin-top: 0px;
  margin-left: 0px;
  -webkit-box-shadow: 0 6px 12px rgba(0,0,0,.175);
  box-shadow: 0 6px 12px rgba(0,0,0,.175);
  -moz-box-shadow: 0 6px 12px rgba(0,0,0,.175);
  background-clip: padding-box;
  opacity: 0.97;
  filter: alpha(opacity=97);
}
	.highcharts-point { cursor: pointer;}
</style>
<div class="container">
   <?php //echo $chart_room[0];?>
    <div class="row bhoechie-tab-container">
        <div class="col-md-12">
              

                <div class="panel-body">
                  <?php $array_m=array(1,2,3,4,5,6,7,8,9,10,11,12);
						$array_value=array(5=>3,6=>11,7=>2);
						$newArray=array();
						foreach($array_m as $km){
							if(isset($array_value[$km])){
								$newArray[]=$array_value[$km];
								
							}else{
								$newArray[]=0;
							}
						}
						// echo json_encode($newArray);
					?>
                 	<?php $bordercolor=array_reverse($array_color);?>
                        <div class="row">
                  		
                        </div>
                        <div class="row">
                        	<div id="chartRoomInv" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
                  		</div>
                  		<div class="row">
                       	<div class="panel panel-default">
							<div class="panel-body">
								<div class="col-md-6">
												<p style="border-bottom: 1px dashed teal;"><strong>Out of Stock</strong></p>
													@foreach(App\Tbl_item::all() as $objINV)
													@if( $objINV->getCountItemStock($objINV->id) ==0 )
														<p>
														{{$objINV->item_code}} - 
														{{$objINV->item_name}} : 
														<span style="color:darkred">
														{{$objINV->getCountItemStock($objINV->id)}}
														</span>
														</p>
													@endif	
													@endforeach
								</div>
								<div class="col-md-6">
												<p style="border-bottom: 1px dashed teal;"><strong>New Item</strong></p>
													@foreach(App\Tbl_item::orderBy('id','DESC')->limit(9)->get() as $objINV)
														<p>
														{{$objINV->item_code}} - 
														{{$objINV->item_name}} : 
														<span style="color:darkred">
														{{$objINV->getCountItemStock($objINV->id)}}
														</span>
														</p>

													@endforeach
								</div>
							</div>
							</div>
                  		</div>
                </div>
        </div>
    </div>
</div>
<!-- Modal -->
<div class="modal fade" id="modelShowItemInRoom" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel" style="color: teal;">Inventory In Room <span id="headingTitle"></span></h4>
      </div>
      <div class="modal-body">
       
      </div>
      
    </div>
  </div>
</div>
@endsection

@section('jquery')
<script src ="{{ asset('js/highcharts.js') }}"></script>
<script src ="{{ asset('js/drilldown.js') }}"></script>

 <script type="text/javascript">
$(function () {

    // Create the chart
    $('#chartRoomInv').highcharts({
        chart: {
            type: 'column',
			
        },
        title: {
            text: 'Construction Summary'
        },
        xAxis: {
            type: 'category'
        },

        legend: {
            enabled: false
        },


        plotOptions: {
            series: {
                borderWidth: 0,
                dataLabels: {
                    enabled: false
                },
				point: {
						
						events: {
							click: function () {
								console.log(this);
								console.log(this.options.series[0].name);
								console.log(this.options.series[0].data[0].name);
								alert('name: ' + console.log(this));
								if(this.name!=null){
									
								}
								
							}
						}
				}
            }
			
       },

        series: [{
            name: 'Room',
            colorByPoint: true,
            data:<?php echo preg_replace('/&#039;/',"'",$chart_room[0]) ?>
			
        }],
        drilldown: {
			name: '1011 Actual',
            series: <?php echo preg_replace('/&#039;/',"'",$chart_room[1]) ?>
        }
    });
});

			

	</script>
@endsection
