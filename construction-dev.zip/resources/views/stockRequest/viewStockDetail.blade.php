<table class="table table-striped table-bordered" id="itable">
    <thead>
        <tr>
            <th>#</th>
            <th>Item Code</th>
            <th>Item Name</th>
            <th>Amount</th>
        </tr>
    </thead>
    <tbody>
        <?php $x = 1;?>
        @foreach($getSaleDetails as $inv)
        <tr>
            <td>{{ $x }}</td>
            <td>{{ $inv->item_code }}</td>
            <td>{{ $inv->item_name }}</td>
            <td>{{ $inv->qty }}</td>
        </tr>
        <?php $x++;?>
        @endforeach
    </tbody>
</table>