<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use App\Http\Requests;
use App\Tbl_staffs;
use App\Tbl_department;


class StaffController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        return view('/staffList.stafflists');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $staff_id=request('staff_id');
        if($staff_id){
            Tbl_staffs::where('id', $staff_id)
                ->update([
                    'department_id'=>request('department'),
                    'staff_name'=>request('fullName'),
                    'staff_code'=>request('code'),
                    'phone_number'=>request('mobile'),
                    'gender'=>request('gender'),
                    'position'=>request('position')
                ]);
        }else{
            Tbl_staffs::create([
                'department_id'=>request('department'),
                'staff_name'=>request('fullName'),
                'staff_code'=>request('code'),
                'phone_number'=>request('mobile'),
                'gender'=>request('gender'),
                'position'=>request('position')
                ]);
        }
        return redirect('/staffLists');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }
    public function addNewStaffForm(){
        return view('vendor.newStaff');
    }
    public function editStaff($id){
        $getSelectEdit = Tbl_staffs::where('id',$id)->get();
        return view('vendor.newStaff')->with('getSelectEdit',$getSelectEdit);
    }
    public function listEachDeptpartment($id)
    {
        $selectDept = Tbl_staffs::where('department_id',$id)->get();
        return view('/staffList.stafflists')->with('dept_id',$selectDept);
    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
       //
    }
}
