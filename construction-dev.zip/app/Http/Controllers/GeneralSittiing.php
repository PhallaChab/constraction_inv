<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\TblTaxRate;
use App\tbl_tax_component;
use App\Tbl_department;
use App\ItemCategory;
use App\User;
use App\Tbl_Role;
/*use App\Tbl_Condo_Floor;
use App\Tbl_Condo;*/

use App\Http\Requests;
use Auth;
use Input;
use Hash;

class GeneralSittiing extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('general.general');
    }
    //manage department
    public function department(){
        $getDept = Tbl_department::get();
        return view('general.department')->with('getDept',$getDept);
    }

    public function addDepartment(){
        return view('vendor.newDepartment');
    }

    public function creatDeptForm()
    {
        //
        $dept_id=request('dept_id');
        if($dept_id){
            Tbl_department::where('id', $dept_id)->update([  
                'department_name'=>request('department')
            ]);
        }else{
            Tbl_department::create([
                'department_name'=>request('department')
            ]);
        }
    }

    public function editDept($id)
    {
        $selectEditDept = Tbl_department::where('id',$id)->get();
        return view('vendor.newDepartment')->with('selectEditDept',$selectEditDept);
    }

    public function deleteDept(){
        $id = request('dept_id');
        $delete = Tbl_department::where('id', $id)->delete();
        if($delete==1){
            return 'yes';
        }else{
            return 'no';
        }
    }
    // end manage department

    //manage category item
    public function categoryItem()
    {
        $getCate = ItemCategory::get();
        return view('general.categoryItem')->with('getCate',$getCate);
    }
    public function addCategory()
    {
        return view('vendor.newCategory');
    }
    public function createCateForm()
    {
        $cate_id=request('cate_id');
        if($cate_id){
            ItemCategory::where('id', $cate_id)->update(['category_name'=>request('category')]);
        }else{
            ItemCategory::create(['category_name'=>request('category')]);
        }
    }
    public function editCate($id)
    {
        $selectEditCate = ItemCategory::where('id',$id)->get();
        return view('vendor.newCategory')->with('selectEditCate',$selectEditCate);
    }
    public function deleteCate(){
        $id = request('cate_id');
        $delete = ItemCategory::where('id', $id)->delete();
        if($delete==1){
            return 'yes';
        }else{
            return 'no';
        }
    }
    //end manage category item

    //manage user
    public function registerUser()
    {
        $getUser = User::get();
        return view('general.users')->with('getUsers',$getUser);
    }
    public function addUser()
    {
        $role = Tbl_Role::get();
        $getDept = Tbl_department::get();
        return view('vendor.newUsers')->with(array(
                                        'role'=>$role,
                                        'department'=>$getDept
                                    ));
    }
    public function createNewUser()
    {
        $userID = request('userID');
        if($userID){
            User::where('id',$userID)->update([
                'name' => request('name'),
                'email' => request('email'),
                'role_id' => request('role'),
                'dept_id'=>request('dept_id'),
                'position'=>request('position'),
                'telephone'=>request('telephone')
            ]);
        }else{
            User::create([
                'name' => request('name'),
                'role_id' => request('role'),
                'dept_id'=>request('dept_id'),
                'email' => request('email'),
                'position'=>request('position'),
                'telephone'=>request('telephone'),
                'password' => bcrypt(request('password'))
            ]);
        }
        return redirect('/newUser');
    }
     public function editUser($id)
    {
        $role = Tbl_Role::get();
        $getDept = Tbl_department::get();
        $selectEditUser = User::where('id',$id)->get();
        return view('vendor.newUsers')->with(array(
                                            'selectEditUser'=>$selectEditUser,
                                            'department'=>$getDept,
                                            'role'=>$role));
    }
    public function checkEmailExist(){
        $email = request('checkEmail');
        $userID = request('userid');

        if(!empty($userID)){
            $queries =User::where(array('email'=>$email,'id'=>$userID))->count();
            if ($queries > 0){
                echo 'true';
            }else{
                $queries2 =User::where('email',$email)->count();
                if ($queries2 > 0){
                    echo 'false';
                }else{
                    echo 'true';
                }
            }
        }else{
            $queries2 =User::where('email',$email)->count();
            if ($queries2 > 0){
                echo 'false';
            }else{
                echo 'true';
            }
        }
    }

    public function deleteUser(){
        $userID = request('user_id');
        $query = User::where('id',$userID)->delete();
        if($query){
            return 'yes';
        }else{
            return "no";
        }
    }

    public function changePassword(){
        $userID = Auth::user()->id;
        $selectEditUser = User::where('id',$userID)->get();
        return view('vendor.changePassword')->with('selectEditUser',$selectEditUser);
    }
    public function updatePassword(){
        $userID = Auth::user()->id;
        $oldPass = request('oldpassword');
        $userpass = Auth::user()->password;
        $newpass = bcrypt(request('newpassword'));
        $username = request('username');

        if (Hash::check($oldPass, $userpass))
        {
            $updatPass = User::where('id',$userID)
                ->update([
                    'password' => $newpass,
                    'name' => $username
                ]);
            if($updatPass){
                echo "yes";
            }else{
                echo "no";
            }
        }else{
            echo "nono";
        }  

    }
    //manage condo room
    /*public function showRoom(){
        $condoRoom = Tbl_Condo::get();
        return view('general.condoRoom')->with("condoRoom",$condoRoom);
    }*/
    /*public function getModalRoom(){
        $condoFloor = Tbl_Condo_Floor::get();
        return view('vendor.newRoom')->with('condoFloor',$condoFloor);
    }*/
    /*public function newRoom(){
        $room_id = request('room_id');
        if($room_id){
            Tbl_Condo::where('id',$room_id)->update([
                'condo_name'=>request('roomName'),
                'floor_id'=>request('floor')
            ]);
        }else{
            Tbl_Condo::create([
                'condo_name'=>request('roomName'),
                'floor_id'=>request('floor')
            ]);
        }
    }*/
    /*public function showRoomId($id){
        $condoFloor = Tbl_Condo_Floor::get();
        $showRoomid = Tbl_Condo::where('id',$id)->get();
        return view('vendor.newRoom')->with(array('showRoomid'=>$showRoomid,'condoFloor'=>$condoFloor));
    }*/
    /*public function distroyroom(){
        $id = request('room_id');
        $delete = Tbl_Condo::where('id', $id)->delete();
        if($delete){
            return 'yes';
        }else{
            return 'no';
        }
    }*/

    // manage condo floor
    /*public function showfloor(){
        $condoFloors = Tbl_Condo_Floor::get();
        return view('general.condoFloor')->with("condoFloors",$condoFloors);
    }
    public function getModalFloor(){
        return view('vendor.newFloor');
    }
    public function newFloor(){
        $floor_id = request('floor_id');
        if($floor_id){
            Tbl_Condo_Floor::where('id',$floor_id)->update([
               'floor'=>request('floorName')
            ]);
        }else{
            Tbl_Condo_Floor::create([
                'floor'=>request('floorName')
            ]);
        }
    }
    public function showFloorId($id){
        $showFloorid = Tbl_Condo_Floor::where('id',$id)->get();
        return view('vendor.newFloor')->with('showFloorid',$showFloorid);
    }
    public function distroyfloor(){
        $id = request('floor_id');
        $delete = Tbl_Condo_Floor::where('id', $id)->delete();
        if($delete){
            return 'yes';
        }else{
            return 'no';
        }
    }*/

}
