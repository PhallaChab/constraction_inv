<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Tbl_Item_Stock;
use App\tbl_sale_invs;

class StockController extends Controller
{
    //
    public function warehouse(){
        $countRequest=array();
        $countRequest[0]=tbl_sale_invs::where('status',1)->get()->count();
        $countRequest[1]=tbl_sale_invs::where('status',2)->get()->count();
        $countRequest[2]=tbl_sale_invs::where('status','!=',0)->get()->count();
        $getSaleInv = tbl_sale_invs::where('status','!=',0)->get();

        return view('warehouse.warehouse')->with(array('getSaleInv'=>$getSaleInv,'countRequest'=>$countRequest));
    }

    public function listWareHouseManagement($status){
        $countRequest=array();
        /*for($i=0;$i< 3;$i++){
        	$countRequest[$i]=tbl_sale_invs::CountInvSale($status);
        }*/
        $countRequest[0]=tbl_sale_invs::where('status',1)->get()->count();
        $countRequest[1]=tbl_sale_invs::where('status',2)->get()->count();
        $countRequest[2]=tbl_sale_invs::where('status','!=',0)->get()->count();
		
        if($status==2){
            $getSaleInv = tbl_sale_invs::where('status','!=',0)->get();
        }else if($status==0){
            $getSaleInv=tbl_sale_invs::where('status',1)->get();
        }else if($status==1){
            $getSaleInv=tbl_sale_invs::where('status',2)->get();
        }
        return view('warehouse.warehouse')->with(array(
                                                    'getSaleInv'=>$getSaleInv,
                                                    'countRequest'=>$countRequest,
                                                    'status'=>$status));
    }

    public function addStockOut(){
    	$itemid = request('itemid');
    	$qty = request('qty');
    	$saleid = request('saleInvid');
    	$date = request('dateDelever');
    	foreach($itemid as $itemkey=>$itemValue){
    		$query = Tbl_Item_Stock::create([
	    		'item_id'=>$itemValue,
				'amount'=>$qty[$itemkey],
				'inv_sale_id'=>$saleid[$itemkey],
				'toDate'=>$date,
				'status'=>1
	    	]);
	    	tbl_sale_invs::where('id',$saleid[$itemkey])->update([
				'status'=>2
	    	]);
    	}
    	
    }
}
