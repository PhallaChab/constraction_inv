<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ItemCategory extends Model
{
    //
	protected $table='tbl_categories';
	protected $fillable= [
		'id',
		'category_name'
	];

	public function getItemList(){
    	return $this->hasMany('App\Tbl_item', 'item_category_id');
    }

}
