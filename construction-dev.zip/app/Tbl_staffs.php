<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\tbl_sale_invs;
class Tbl_staffs extends Model
{
    //
	protected $table='tbl_staffs';

	protected $fillable = [
		'department_id',
		'staff_name',
		'staff_code',
		'phone_number',
		'gender',
		'position',
	];
	
	public function getDepartment(){
		return $this->belongsTo('App\Tbl_department', 'id');
	}

	public function getDepartmentName(){
		$query=Tbl_department::all();
		$array_category=array();
		foreach($query as $obj){
			$array_category[$obj->id]=$obj->department_name;
		}
    	return $array_category;
    }
	public function getItemCount($staffID){
			$query=tbl_sale_invs::where('staff_id',$staffID)->get()->count();
			return $query;
		}
}
