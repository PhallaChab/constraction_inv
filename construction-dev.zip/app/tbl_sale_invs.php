<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

use Auth;

class tbl_sale_invs extends Model
{
    //
    protected $table ='tbl_sale_invs';
    protected $fillable = [
    	'user_id',
        'toDate',
        'status',
        'invoid_code'
    ];
	
	public function saleDeail(){
			
		return $this->hasMany('App\tbl_sale_details', 'sale_inv_id');
		//return $this->belongsToOne(Sub_menu::class);
		}
	
	public function getItem($id){
		$query=Tbl_item::where('id',$id)->get();
		$array_item=array();
		foreach($query as $obj){
				$array_item[0][$obj->id]=$obj->item_code;
				$array_item[1][$obj->id]=$obj->item_name;
			}
    	return $array_item;
	}
	public function getItem_stock($id){
		$query=Tbl_Item_Stock::where('item_id',$id)->get();
		$array_item_stock=array();
		foreach($query as $obj){
				$array_item_stock[$obj->inv_sale_id]=$obj->id;
			}
    	return $array_item_stock;
    }
    public static function getSaleInv(){
    	return tbl_sale_invs::where('user_id',Auth::user()->id)->get();
    }
    public static function checkTakeOutStatus($sale_id){
    	return Tbl_Item_Stock::where('inv_sale_id',$sale_id)->get()->count();
    }

    public static function CountInvSale($status){
    	return tbl_sale_invs::where('status',$status)->get()->count();
    }

}
